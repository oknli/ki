import { NextRequest, NextResponse } from 'next/server'
import { getUserByEmail, verifyPassword, createToken } from '@/lib/auth'

export async function POST(request) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json(
        { error'Email and password are required' },
        { status)
    }

    // Get user
    const user = await getUserByEmail(email)
    if (!user) {
      return NextResponse.json(
        { error'Invalid email or password' },
        { status)
    }

    // Verify password
    const isValid = await verifyPassword(password, user.password)
    if (!isValid) {
      return NextResponse.json(
        { error'Invalid email or password' },
        { status)
    }

    // Create token
    const token = createToken(user.id)

    // Create response with cookie
    const response = NextResponse.json(
      { success.id, email.email },
      { status)

    response.cookies.set('auth-token', token, {
      httpOnly.env.NODE_ENV === 'production',
      sameSite'lax',
      maxAge* 24 * 60 * 60, // 7 days
    })

    return response
  } catch (error) {
    console.error('[v0] Login error:', error)
    return NextResponse.json(
      { error'Login failed' },
      { status)
  }
}
