import { NextRequest, NextResponse } from 'next/server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)
const businessEmail = process.env.BUSINESS_EMAIL || 'noreply@genesis-ai-pro.com'

export async function POST(req) {
  try {
    const body = await req.json()
    const { From, Body, To, MessageSid } = body

    if (!From || !Body) {
      return NextResponse.json(
        { error'Missing required fields' },
        { status)
    }

    // Email the business about incoming SMS
    const emailResponse = await resend.emails.send({
      from'Twilio Webhook <webhook@resend.dev>',
      to`New SMS from ${From}`,
      html`
        <h2>New Incoming SMS</h2>
        <p><strong>From/strong> ${From}</p>
        <p><strong>Message/strong> ${Body}</p>
        <p><strong>Message ID/strong> ${MessageSid}</p>
        <p><small>Received at${new Date().toISOString()}</small></p>
      `,
    })

    console.log('SMS webhook received and forwarded:', { From, MessageSid })

    return NextResponse.json({ success.id }, { status)
  } catch (error) {
    console.error('SMS webhook error:', error)
    return NextResponse.json(
      { error'Failed to process SMS webhook' },
      { status)
  }
}
