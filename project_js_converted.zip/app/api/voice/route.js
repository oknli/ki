import { NextRequest, NextResponse } from 'next/server'

export async function POST(req) {
  try {
    // Twilio sends voice call queries-encoded POST data
    const searchParams = new URLSearchParams(await req.text())
    const from = searchParams.get('From') || 'Unknown'
    const callSid = searchParams.get('CallSid') || 'Unknown'

    console.log(`Voice call received from ${from}, CallSid${callSid}`)

    // Generate TwiML response for IVR/greeting
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice">
    Thank you for calling Genesis AI Pro.
    Your call is very important to us.
    Please hold while we connect you with the next available agent.
  </Say>
  <Queue>default</Queue>
</Response>`

    return new NextResponse(twiml, {
      status'Content-Type''application/xml' },
    })
  } catch (error) {
    console.error('Voice call handler error:', error)
    return NextResponse.json({ error'Failed to handle voice call' }, { status)
  }
}
