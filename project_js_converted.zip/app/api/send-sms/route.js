import { smsSchema } from '@/lib/validation'
import { NextRequest, NextResponse } from 'next/server'

const accountSid = process.env.TWILIO_ACCOUNT_SID
const authToken = process.env.TWILIO_AUTH_TOKEN
const fromPhone = process.env.TWILIO_FROM_PHONE

if (!accountSid || !authToken || !fromPhone) {
  console.error('Missing Twilio credentials in environment variables')
}

export async function POST(req) {
  try {
    const body = await req.json()
    const validated = smsSchema.parse(body)

    if (!accountSid || !authToken || !fromPhone) {
      return NextResponse.json(
        { error'SMS service is not configured' },
        { status)
    }

    const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
      method'POST',
      headers'Authorization''Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
        'Content-Type''application/x-www-form-urlencoded',
      },
      body({
        To.phone,
        From.message,
      }).toString(),
    })

    if (!response.ok) {
      const error = await response.json()
      console.error('Twilio error:', error)
      return NextResponse.json(
        { error'Failed to send SMS' },
        { status.status }
      )
    }

    const data = await response.json()
    return NextResponse.json({
      success.sid,
      message'SMS sent successfully',
    })
  } catch (error) {
    if (error instanceof Error && error.message.includes('validation')) {
      return NextResponse.json(
        { error'Invalid phone number or message format' },
        { status)
    }

    console.error('Send SMS error:', error)
    return NextResponse.json(
      { error'Failed to send SMS' },
      { status)
  }
}
