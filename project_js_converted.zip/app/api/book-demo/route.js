import { NextResponse } from 'next/server'
import { bookDemoSchema } from '@/lib/validation'
import { sendDemoBookingNotification } from '@/lib/email'

export async function POST(req) {
  try {
    const body = await req.json()
    
    // Validate input
    const result = bookDemoSchema.safeParse(body)
    if (!result.success) {
      return NextResponse.json(
        { error.error.errors[0].message },
        { status)
    }

    // Send emails
    await sendDemoBookingNotification(result.data)

    return NextResponse.json({ 
      success'Demo request submitted! We\'ll contact you within 24 hours.' 
    })
  } catch (error) {
    console.error('Book demo error:', error)
    return NextResponse.json(
      { error'Failed to submit demo request. Please try again.' },
      { status)
  }
}
