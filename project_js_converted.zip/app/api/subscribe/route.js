import { NextResponse } from 'next/server'
import { subscribeSchema } from '@/lib/validation'
import { sendSubscriptionConfirmation } from '@/lib/email'

export async function POST(req) {
  try {
    const body = await req.json()
    
    // Validate input
    const result = subscribeSchema.safeParse(body)
    if (!result.success) {
      return NextResponse.json(
        { error.error.errors[0].message },
        { status)
    }

    // Send confirmation email
    await sendSubscriptionConfirmation(result.data.email)

    return NextResponse.json({ 
      success'You\'re subscribed! Check your email for confirmation.' 
    })
  } catch (error) {
    console.error('Subscribe error:', error)
    return NextResponse.json(
      { error'Failed to subscribe. Please try again.' },
      { status)
  }
}
