import { NextRequest, NextResponse } from 'next/server'
import { findUserByEmail } from '@/lib/users'

export async function POST(request) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json(
        { error'Email and password are required' },
        { status)
    }

    // Find user by email
    const user = findUserByEmail(email)
    
    if (!user) {
      return NextResponse.json(
        { error'Invalid email or password' },
        { status)
    }

    // Check password
    if (user.password !== password) {
      return NextResponse.json(
        { error'Invalid email or password' },
        { status)
    }

    return NextResponse.json({
      user.id,
        name.name,
        email.email,
      },
      message'Login successful',
    })
  } catch (error) {
    console.error('[login error]', error)
    return NextResponse.json(
      { error'Server error' },
      { status)
  }
}
