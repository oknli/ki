import { NextRequest, NextResponse } from 'next/server'
import { createUser, findUserByEmail } from '@/lib/users'

export async function POST(request) {
  try {
    const { name, email, password } = await request.json()

    // Validation
    if (!name || !email || !password) {
      return NextResponse.json(
        { error'Name, email, and password are required' },
        { status)
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error'Password must be at least 6 characters' },
        { status)
    }

    // Check if email already exists
    const existingUser = findUserByEmail(email)
    if (existingUser) {
      return NextResponse.json(
        { error'Email already in use' },
        { status)
    }

    // Create new user
    const newUser = createUser(name, email, password)

    return NextResponse.json({
      user.id,
        name.name,
        email.email,
      },
      message'Account created successfully',
    })
  } catch (error) {
    console.error('[signup error]', error)
    return NextResponse.json(
      { error'Server error' },
      { status)
  }
}
