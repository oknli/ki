import { NextResponse } from 'next/server'
import { contactSchema } from '@/lib/validation'
import { sendContactNotification } from '@/lib/email'

export async function POST(req) {
  try {
    const body = await req.json()
    
    // Validate input
    const result = contactSchema.safeParse(body)
    if (!result.success) {
      return NextResponse.json(
        { error.error.errors[0].message },
        { status)
    }

    // Send emails
    await sendContactNotification(result.data)

    return NextResponse.json({ 
      success'Your message has been sent successfully!' 
    })
  } catch (error) {
    console.error('Contact form error:', error)
    return NextResponse.json(
      { error'Failed to send message. Please try again.' },
      { status)
  }
}
