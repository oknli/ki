import { NextRequest, NextResponse } from 'next/server'
import { createUser, getUserByEmail } from '@/lib/auth'
import { initDatabase } from '@/lib/db'

export async function POST(request) {
  try {
    // Initialize database on first run
    await initDatabase()

    const { name, email, password } = await request.json()

    if (!name || !email || !password) {
      return NextResponse.json(
        { error'Name, email, and password are required' },
        { status)
    }

    // Check if user already exists
    const existingUser = await getUserByEmail(email)
    if (existingUser) {
      return NextResponse.json(
        { error'Email already registered' },
        { status)
    }

    // Create user
    const user = await createUser(name, email, password)

    return NextResponse.json(
      { success.id, email.email },
      { status)
  } catch (error) {
    console.error('[v0] Signup error:', error)
    return NextResponse.json(
      { error'Signup failed' },
      { status)
  }
}
