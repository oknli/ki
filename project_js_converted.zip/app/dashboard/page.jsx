'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { toast } from 'sonner'
import { Phone, Mail, MessageSquare, MessageCircle, Calendar, Users, BarChart3, LogOut } from 'lucide-react'


    setUser(JSON.parse(storedUser))
    setLoading(false)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('user')
    localStorage.removeItem('auth-token')
    toast.success('Logged out successfully')
    router.push('/')
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-slate-600">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  const features = [
    {
      icon'Call Management',
      description'Track all incoming and outgoing calls',
      href'#calls'
    },
    {
      icon'Email Integration',
      description'Manage your emails in one place',
      href'#emails'
    },
    {
      icon'SMS & Text',
      description'Send and receive text messages',
      href'#sms'
    },
    {
      icon'Live Chat',
      description'Real-time communication with customers',
      href'#chat'
    },
    {
      icon'Calendar Booking',
      description'Schedule appointments automatically',
      href'#calendar'
    },
    {
      icon'Unified Inbox',
      description'All messages in one place',
      href'#inbox'
    },
  ]

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm-6 lg-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Genesis AI Pro</h1>
            <p className="text-slate-600">Welcome, {user?.name}!</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover-red-700 text-white rounded-lg transition"
          >
            <LogOut size={20} />
            Logout
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm-6 lg-8 py-12">
        {/* Stats Section */}
        <div className="grid grid-cols-1 md-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm">Total Contacts</p>
                <p className="text-3xl font-bold text-slate-900">0</p>
              </div>
              <Users className="text-blue-600" size={32} />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm">Messages Today</p>
                <p className="text-3xl font-bold text-slate-900">0</p>
              </div>
              <MessageCircle className="text-green-600" size={32} />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm">Upcoming Calls</p>
                <p className="text-3xl font-bold text-slate-900">0</p>
              </div>
              <Phone className="text-purple-600" size={32} />
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">Communication Features</h2>
          <div className="grid grid-cols-1 md-cols-2 lg-cols-3 gap-6">
            {features.map((feature) => {
              const Icon = feature.icon
              return (
                <div
                  key={feature.title}
                  className="bg-white rounded-lg shadow hover-lg transition p-6 cursor-pointer group"
                >
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-blue-50 rounded-lg group-hover-blue-100 transition">
                      <Icon className="text-blue-600" size={24} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-slate-900 mb-1">{feature.title}</h3>
                      <p className="text-slate-600 text-sm">{feature.description}</p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Quick Actions</h2>
          <div className="flex flex-wrap gap-3">
            <button className="px-4 py-2 bg-blue-600 hover-blue-700 text-white rounded-lg transition">
              Add Contact
            </button>
            <button className="px-4 py-2 bg-green-600 hover-green-700 text-white rounded-lg transition">
              New Message
            </button>
            <button className="px-4 py-2 bg-purple-600 hover-purple-700 text-white rounded-lg transition">
              Schedule Call
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}
