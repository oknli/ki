import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from 'sonner'
import './globals.css'

const inter = Inter({ 
  subsets"latin"],
  variable'--font-inter'
});

export const metadata= {
  title'Genesis AI Pro | AI-Powered Communication Platform',
  description'Manage all your calls, emails, texts, and web chats in one unified inbox. Automatically book appointments to your calendar. Built for local small businesses.',
  generator'v0.app',
  icons'/icon-light-32x32.png',
        media'(prefers-color-scheme)',
      },
      {
        url'/icon-dark-32x32.png',
        media'(prefers-color-scheme)',
      },
      {
        url'/icon.svg',
        type'image/svg+xml',
      },
    ],
    apple'/apple-icon.png',
  },
}

export default function RootLayout({
  children,
}.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} font-sans antialiased`}>
        {children}
        <Toaster 
          position="top-right" 
          toastOptions={{
            style'#0B3C5D',
              color'white',
              border'1px solid rgba(255,255,255,0.1)',
            },
          }}
        />
        <Analytics />
      </body>
    </html>
  )
}
