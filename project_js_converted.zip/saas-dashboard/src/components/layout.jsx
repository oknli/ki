import { useLocation, Link } from "wouter";
import { useLogout, User } from "@workspace/api-client-react";
import { LayoutDashboard, MessageSquare, Mail, Phone, Bot, Calendar, Inbox, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href"/dashboard", label"Overview", icon"/dashboard/sms", label"SMS", icon"/dashboard/email", label"Email", icon"/dashboard/calls", label"Calls", icon"/dashboard/chat", label"AI Chat", icon"/dashboard/calendar", label"Calendar", icon"/dashboard/inbox", label"Inbox", icon;

export default function Layout({ children, user }.ReactNode, user) {
  const [location, setLocation] = useLocation();
  const logout = useLogout();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess() => {
        localStorage.removeItem("authToken");
        setLocation("/login");
      }
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <aside className="w-64 border-r bg-card flex flex-col">
        <div className="p-6">
          <h1 className="text-xl font-bold tracking-tight">Genesis AI Pro</h1>
        </div>
        <nav className="flex-1 px-4 space-y-1">
          {NAV_ITEMS.map((item) => (
            <Link key={item.href} href={item.href} className={cn("flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors", location === item.href ? "bg-primary text-primary-foreground" "hover-muted text-muted-foreground")}>
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t">
          <div className="flex items-center justify-between">
            <div className="text-sm font-medium truncate pr-2">{user.name}</div>
            <button onClick={handleLogout} className="p-2 hover-muted rounded-md text-muted-foreground" title="Log out">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}
