import * from "react"
import * from "@radix-ui/react-toggle"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const toggleVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium transition-colors hover-muted hover-muted-foreground focus-visible-none focus-visible-1 focus-visible-ring disabled-events-none disabled-50 data-[state=on]-accent data-[state=on]-accent-foreground [&_svg]-events-none [&_svg]-4 [&_svg]-0",
  {
    variants"bg-transparent",
        outline"border border-input bg-transparent shadow-sm hover-accent hover-accent-foreground",
      },
      size"h-9 px-2 min-w-9",
        sm"h-8 px-1.5 min-w-8",
        lg"h-10 px-2.5 min-w-10",
      },
    },
    defaultVariants"default",
      size"default",
    },
  }
)

const Toggle = React.forwardRef<
  React.ElementRef<typeof TogglePrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof TogglePrimitive.Root> &
    VariantProps<typeof toggleVariants>
>(({ className, variant, size, ...props }, ref) => (
  <TogglePrimitive.Root
    ref={ref}
    className={cn(toggleVariants({ variant, size, className }))}
    {...props}
  />
))

Toggle.displayName = TogglePrimitive.Root.displayName

export { Toggle, toggleVariants }
