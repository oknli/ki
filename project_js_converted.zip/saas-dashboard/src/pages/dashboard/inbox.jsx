import { useGetInbox } from "@workspace/api-client-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageSquare, Mail, Bot, ArrowRightLeft, ArrowLeftRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

type FilterType = "all" | "sms" | "chat" | "email";

export default function Inbox() {
  const [filter, setFilter] = useState<FilterType>("all");
  const { data= useGetInbox(
    filter === "all" ? undefined );

  const getChannelIcon = (channel) => {
    switch (channel) {
      case "sms"="h-4 w-4" />;
      case "chat"="h-4 w-4" />;
      case "email"="h-4 w-4" />;
      default="h-4 w-4" />;
    }
  };

  const getChannelColor = (channel) => {
    switch (channel) {
      case "sms""bg-blue-500/10 text-blue-500 hover-blue-500/20";
      case "chat""bg-emerald-500/10 text-emerald-500 hover-emerald-500/20";
      case "email""bg-purple-500/10 text-purple-500 hover-purple-500/20";
      default"bg-gray-500/10 text-gray-500 hover-gray-500/20";
    }
  };

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-6">
      <div className="flex flex-col md-row justify-between items-start md-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Unified Inbox</h2>
          <p className="text-muted-foreground">All your customer communications in one place.</p>
        </div>
        <div className="flex bg-muted/50 p-1 rounded-lg">
          <Button 
            variant={filter === "all" ? "secondary" "ghost"} 
            size="sm" 
            onClick={() => setFilter("all")}
            className="rounded-md"
          >
            All
          </Button>
          <Button 
            variant={filter === "sms" ? "secondary" "ghost"} 
            size="sm" 
            onClick={() => setFilter("sms")}
            className="rounded-md"
          >
            SMS
          </Button>
          <Button 
            variant={filter === "email" ? "secondary" "ghost"} 
            size="sm" 
            onClick={() => setFilter("email")}
            className="rounded-md"
          >
            Email
          </Button>
          <Button 
            variant={filter === "chat" ? "secondary" "ghost"} 
            size="sm" 
            onClick={() => setFilter("chat")}
            className="rounded-md"
          >
            Chat
          </Button>
        </div>
      </div>

      <div className="bg-card border rounded-xl shadow-sm overflow-hidden flex flex-col min-h-[600px]">
        <div className="p-3 border-b bg-muted/20">
          <Input placeholder="Search inbox..." className="max-w-md bg-background" />
        </div>
        
        <div className="flex-1 overflow-auto">
          {isLoading ? (
            <div className="p-4 space-y-4">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="flex gap-4 items-center">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-4 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) ?.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground p-12">
              <Mail className="h-16 w-16 mb-4 opacity-20" />
              <p className="text-lg font-medium">Inbox is empty</p>
              <p className="text-sm">You're all caught up!</p>
            </div>
          ) (
            <div className="divide-y">
              {inbox?.map((item) => (
                <div key={item.id} className="p-4 hover-muted/50 transition-colors flex gap-4 items-start group cursor-pointer">
                  <div className={`mt-1 h-10 w-10 rounded-full flex items-center justify-center shrink-0 ${
                    item.channel === 'sms' ? 'bg-blue-500/10 text-blue-500' .channel === 'email' ? 'bg-purple-500/10 text-purple-500' 'bg-emerald-500/10 text-emerald-500'
                  }`}>
                    {getChannelIcon(item.channel)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2 font-medium truncate">
                        <span className={!item.isRead ? "text-foreground font-bold" "text-foreground/80"}>
                          {item.from}
                        </span>
                        <Badge variant="outline" className={`text-[10px] uppercase tracking-wider font-semibold border-transparent ${getChannelColor(item.channel)}`}>
                          {item.channel}
                        </Badge>
                        {item.direction === 'inbound' ? 
                          <ArrowRightLeft className="h-3 w-3 text-muted-foreground" /> ="h-3 w-3 text-muted-foreground" />
                        }
                      </div>
                      <span className="text-xs text-muted-foreground whitespace-nowrap shrink-0">
                        {format(new Date(item.createdAt), "MMM d, h")}
                      </span>
                    </div>
                    <p className={`text-sm line-clamp-2 ${!item.isRead ? "text-foreground font-medium" "text-muted-foreground"}`}>
                      {item.preview}
                    </p>
                  </div>
                  
                  {!item.isRead && (
                    <div className="w-2 h-2 rounded-full bg-primary mt-2 shrink-0"></div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}