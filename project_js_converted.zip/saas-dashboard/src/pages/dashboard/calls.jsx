import { useGetCalls, useCreateCall, getGetCallsQueryKey, CallDirection, CallStatus } from "@workspace/api-client-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Phone, PhoneCall, PhoneIncoming, PhoneMissed, Plus, Clock } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

export default function Calls() {
  const { data= useGetCalls();
  const [isOpen, setIsOpen] = useState(false);
  const [direction, setDirection] = useState<CallDirection>("outbound");
  const [status, setStatus] = useState<CallStatus>("completed");
  const [phone, setPhone] = useState("");
  const [duration, setDuration] = useState("");
  const [notes, setNotes] = useState("");

  const createCall = useCreateCall();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleLogCall = (e.FormEvent) => {
    e.preventDefault();
    if (!phone) return;

    createCall.mutate(
      { 
        data=== 'outbound' ? phone "Me", 
          from=== 'inbound' || direction === 'missed' ? phone "Me",
          duration(duration) || 0,
          notes
        } 
      },
      {
        onSuccess() => {
          setIsOpen(false);
          setPhone("");
          setNotes("");
          setDuration("");
          toast({ title"Call logged", description"The call has been added to your log." });
          queryClient.invalidateQueries({ queryKey() });
        }
      }
    );
  };

  const getStatusBadge = (status) => {
    switch(status) {
      case "completed"="default" className="bg-green-500/10 text-green-500 hover-green-500/20 border-green-500/20">Completed</Badge>;
      case "missed"="destructive" className="bg-red-500/10 text-red-500 hover-red-500/20 border-red-500/20">Missed</Badge>;
      case "failed"="secondary" className="bg-yellow-500/10 text-yellow-500 hover-yellow-500/20 border-yellow-500/20">Failed</Badge>;
    }
  };

  const getDirectionIcon = (direction) => {
    switch(direction) {
      case "outbound"="h-4 w-4 text-blue-500" />;
      case "inbound"="h-4 w-4 text-green-500" />;
      case "missed"="h-4 w-4 text-red-500" />;
    }
  };

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Call Logs</h2>
          <p className="text-muted-foreground">Track and manage your phone communications.</p>
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" /> Log Call</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Log a Call</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleLogCall} className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Direction</label>
                  <Select value={direction} onValueChange={(v) => setDirection(v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="outbound">Outbound</SelectItem>
                      <SelectItem value="inbound">Inbound</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Status</label>
                  <Select value={status} onValueChange={(v) => setStatus(v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="missed">Missed</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Phone Number</label>
                <Input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+1 (555) 000-0000" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Duration (seconds)</label>
                <Input type="number" value={duration} onChange={e => setDuration(e.target.value)} placeholder="120" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Notes</label>
                <Input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Discussed pricing..." />
              </div>
              <Button type="submit" className="w-full" disabled={createCall.isPending || !phone}>
                Save Log
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-card border rounded-xl overflow-hidden shadow-sm">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="w-[50px]"></TableHead>
              <TableHead>Contact</TableHead>
              <TableHead>Date & Time</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Notes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-4" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[150px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[120px]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[60px]" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-[80px] rounded-full" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-[200px]" /></TableCell>
                </TableRow>
              ))
            ) ?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                  <Phone className="h-12 w-12 mx-auto mb-4 opacity-20" />
                  No calls logged yet.
                </TableCell>
              </TableRow>
            ) (
              calls?.map((call) => (
                <TableRow key={call.id}>
                  <TableCell>{getDirectionIcon(call.direction)}</TableCell>
                  <TableCell className="font-medium">{call.direction === 'outbound' ? call.to .from}</TableCell>
                  <TableCell className="text-muted-foreground">{format(new Date(call.createdAt), "MMM d, yyyy h")}</TableCell>
                  <TableCell className="font-mono text-xs">{formatDuration(call.duration)}</TableCell>
                  <TableCell>{getStatusBadge(call.status)}</TableCell>
                  <TableCell className="text-muted-foreground truncate max-w-[300px]">{call.notes || "—"}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}