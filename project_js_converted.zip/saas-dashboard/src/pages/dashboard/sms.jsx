import { useGetMessages, useCreateMessage, getGetMessagesQueryKey } from "@workspace/api-client-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Phone, User, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function SMS() {
  const { data= useGetMessages({ type"sms" });
  const [content, setContent] = useState("");
  const [to, setTo] = useState("");
  const createMessage = useCreateMessage();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSend = (e.FormEvent) => {
    e.preventDefault();
    if (!content || !to) return;

    createMessage.mutate(
      { data"sms", content, to } },
      {
        onSuccess() => {
          setContent("");
          toast({ title"Message sent", description`SMS sent to ${to}` });
          queryClient.invalidateQueries({ queryKey({ type"sms" }) });
        },
        onError() => {
          toast({ variant"destructive", title"Error", description"Failed to send message." });
        }
      }
    );
  };

  return (
    <div className="h-full flex flex-col max-h-[100dvh]">
      <div className="p-6 border-b flex-shrink-0">
        <h2 className="text-2xl font-bold tracking-tight">SMS Messages</h2>
        <p className="text-muted-foreground">Manage and send SMS communications.</p>
      </div>

      <div className="flex-1 overflow-hidden grid grid-cols-1 md-cols-3 gap-0">
        <div className="border-r md-span-1 bg-muted/20 flex flex-col">
          <div className="p-4 font-semibold border-b bg-card">Conversations</div>
          <div className="flex-1 overflow-auto p-4 space-y-3">
            {isLoading ? (
               Array(5).fill(0).map((_, i) => (
                 <Skeleton key={i} className="h-20 w-full" />
               ))
            ) ?.length === 0 ? (
              <div className="text-center p-4 text-muted-foreground">No messages</div>
            ) (
              // Group messages by contact conceptually or just list them
              messages?.slice().reverse().map(msg => (
                <div key={msg.id} className="p-3 bg-card border rounded-lg hover-primary/50 cursor-pointer transition-colors">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium text-sm flex items-center gap-1">
                      <Phone className="h-3 w-3" /> {msg.direction === 'inbound' ? msg.from .to}
                    </span>
                    <span className="text-[10px] text-muted-foreground">{format(new Date(msg.createdAt), "MMM d")}</span>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{msg.content}</p>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="md-span-2 flex flex-col bg-background relative">
          <div className="flex-1 overflow-auto p-6 space-y-4 pb-32">
            {messages?.map((msg) => (
              <div key={msg.id} className={cn("flex", msg.direction === 'outbound' ? "justify-end" "justify-start")}>
                <div className={cn(
                  "max-w-[75%] rounded-2xl p-4 shadow-sm",
                  msg.direction === 'outbound' ? "bg-primary text-primary-foreground rounded-br-sm" "bg-card border rounded-bl-sm"
                )}>
                  <p className="text-sm">{msg.content}</p>
                  <div className={cn("text-[10px] mt-2 flex items-center gap-1", msg.direction === 'outbound' ? "text-primary-foreground/70" "text-muted-foreground")}>
                    <Clock className="w-3 h-3" />
                    {format(new Date(msg.createdAt), "h")}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-4 bg-background/80 backdrop-blur-md border-t">
            <form onSubmit={handleSend} className="flex flex-col gap-3 max-w-3xl mx-auto w-full bg-card p-4 rounded-xl border shadow-sm">
              <div className="flex items-center gap-2 border-b pb-2">
                <span className="text-sm text-muted-foreground font-medium w-8">To/span>
                <Input 
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                  placeholder="+1 (555) 000-0000" 
                  className="border-0 shadow-none focus-visible-0 px-0"
                />
              </div>
              <div className="flex gap-2 items-end">
                <Input 
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Type an SMS message..." 
                  className="flex-1 bg-muted/50 border-transparent focus-visible-background"
                />
                <Button type="submit" size="icon" disabled={createMessage.isPending || !content || !to} className="rounded-full">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}