"use client"

import { useEffect, useState } from "react"
import { X, Mail, Lock, Eye, EyeOff, User } from "lucide-react"



export function SignInModal({ open, onClose }) {
  const [activeTab, setActiveTab] = useState<"signin" | "signup">("signin")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  
  const [signInData, setSignInData] = useState({
    email"",
    password"",
  })
  
  const [signUpData, setSignUpData] = useState({
    name"",
    email"",
    password"",
    confirmPassword"",
  })

  // Handle ESC key
  useEffect(() => {
    const handleEsc = (e) => {
      if (e.key === "Escape") onClose()
    }
    if (open) {
      document.addEventListener("keydown", handleEsc)
      document.body.style.overflow = "hidden"
    }
    return () => {
      document.removeEventListener("keydown", handleEsc)
      document.body.style.overflow = ""
    }
  }, [open, onClose])

  // Reset form when modal closes
  useEffect(() => {
    if (!open) {
      setActiveTab("signin")
      setShowPassword(false)
      setShowConfirmPassword(false)
    }
  }, [open])

  const handleSignIn = (e.FormEvent) => {
    e.preventDefault()
    console.log("Sign in:", signInData)
    onClose()
  }

  const handleSignUp = (e.FormEvent) => {
    e.preventDefault()
    console.log("Sign up:", signUpData)
    onClose()
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-[#0B3C5D]/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md mx-4 bg-white rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full text-white/70 hover-white hover-white/10 transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Gradient Header */}
        <div className="bg-gradient-to-br from-[#0B3C5D] to-[#1C6EA4] px-8 pt-8 pb-12">
          {/* Avatar */}
          <div className="flex justify-center mb-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
              <User className="h-8 w-8 text-white/70" />
            </div>
          </div>

          {/* Header Text */}
          <div className="text-center">
            <h3 className="text-2xl font-bold text-white mb-1">
              Welcome Back
            </h3>
            <p className="text-white/70">
              Sign in to access your Genesis AI Pro dashboard
            </p>
          </div>
        </div>

        {/* Form Area */}
        <div className="px-8 pb-8 -mt-4">
          {/* Tabs */}
          <div className="flex bg-gray-100 rounded-xl p-1 mb-6">
            <button
              onClick={() => setActiveTab("signin")}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === "signin"
                  ? "bg-white text-[#0B3C5D] shadow-sm"
                  "text-[#6B7280] hover-[#0B3C5D]"
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setActiveTab("signup")}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all ${
                activeTab === "signup"
                  ? "bg-white text-[#0B3C5D] shadow-sm"
                  "text-[#6B7280] hover-[#0B3C5D]"
              }`}
            >
              Sign Up
            </button>
          </div>

          {/* Sign In Form */}
          {activeTab === "signin" && (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <label htmlFor="signin-email" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="email"
                    id="signin-email"
                    value={signInData.email}
                    onChange={(e) => setSignInData({ ...signInData, email.target.value })}
                    placeholder="you@business.com"
                    className="w-full rounded-xl border border-gray-200 pl-12 pr-4 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="signin-password" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type={showPassword ? "text" "password"}
                    id="signin-password"
                    value={signInData.password}
                    onChange={(e) => setSignInData({ ...signInData, password.target.value })}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-gray-200 pl-12 pr-12 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover-gray-600"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> ="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-gradient-to-r from-[#00C9A7] to-[#1C6EA4] py-3.5 font-semibold text-white shadow-lg shadow-[#00C9A7]/25 transition-all hover-xl hover-[#00C9A7]/30 hover:-translate-y-0.5 mt-2"
              >
                Sign In
              </button>

              <p className="text-center text-sm text-[#6B7280] mt-4">
                Don&apos;t have an account?{" "}
                <button
                  type="button"
                  onClick={() => setActiveTab("signup")}
                  className="text-[#00C9A7] font-medium hover"
                >
                  Sign up for free
                </button>
              </p>
            </form>
          )}

          {/* Sign Up Form */}
          {activeTab === "signup" && (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div>
                <label htmlFor="signup-name" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    id="signup-name"
                    value={signUpData.name}
                    onChange={(e) => setSignUpData({ ...signUpData, name.target.value })}
                    placeholder="John Smith"
                    className="w-full rounded-xl border border-gray-200 pl-12 pr-4 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="signup-email" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="email"
                    id="signup-email"
                    value={signUpData.email}
                    onChange={(e) => setSignUpData({ ...signUpData, email.target.value })}
                    placeholder="you@business.com"
                    className="w-full rounded-xl border border-gray-200 pl-12 pr-4 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="signup-password" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type={showPassword ? "text" "password"}
                    id="signup-password"
                    value={signUpData.password}
                    onChange={(e) => setSignUpData({ ...signUpData, password.target.value })}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-gray-200 pl-12 pr-12 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover-gray-600"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> ="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <div>
                <label htmlFor="signup-confirm" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type={showConfirmPassword ? "text" "password"}
                    id="signup-confirm"
                    value={signUpData.confirmPassword}
                    onChange={(e) => setSignUpData({ ...signUpData, confirmPassword.target.value })}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-gray-200 pl-12 pr-12 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover-gray-600"
                  >
                    {showConfirmPassword ? <EyeOff className="h-5 w-5" /> ="h-5 w-5" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full rounded-xl bg-gradient-to-r from-[#00C9A7] to-[#1C6EA4] py-3.5 font-semibold text-white shadow-lg shadow-[#00C9A7]/25 transition-all hover-xl hover-[#00C9A7]/30 hover:-translate-y-0.5 mt-2"
              >
                Create Account
              </button>

              <p className="text-center text-sm text-[#6B7280] mt-4">
                Already have an account?{" "}
                <button
                  type="button"
                  onClick={() => setActiveTab("signin")}
                  className="text-[#00C9A7] font-medium hover"
                >
                  Sign in
                </button>
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
