"use client"

import { useState } from "react"
import { Mail, Phone, MapPin, Loader2, CheckCircle } from "lucide-react"
import { toast } from "sonner"

export function Contact() {
  const [formData, setFormData] = useState({
    firstName"",
    lastName"",
    email"",
    phone"",
    message"",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleSubmit = async (e.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const res = await fetch("/api/contact", {
        method"POST",
        headers"Content-Type""application/json" },
        body.stringify(formData),
      })

      const data = await res.json()

      if (!res.ok) {
        toast.error(data.error || "Failed to send message")
        return
      }

      setIsSuccess(true)
      toast.success(data.message)
      setFormData({ firstName"", lastName"", email"", phone"", message"" })
      
      // Reset success state after 3 seconds
      setTimeout(() => setIsSuccess(false), 3000)
    } catch {
      toast.error("Something went wrong. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChange = (e.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name].target.value })
  }

  return (
    <section id="contact" className="bg-[#F7F9FB] py-20 lg-28">
      <div className="mx-auto max-w-7xl px-4 sm-6 lg-8">
        <div className="grid lg-cols-2 gap-12 lg-16">
          {/* Left Column - Contact Info */}
          <div>
            <div className="inline-flex items-center rounded-full bg-[#1C6EA4]/10 px-4 py-1.5 text-sm font-medium text-[#1C6EA4] mb-4">
              Get In Touch
            </div>
            <h2 className="text-3xl sm-4xl font-bold text-[#0B3C5D] mb-4">
              Have Questions?{" "}
              <span className="bg-gradient-to-r from-[#1C6EA4] to-[#00C9A7] bg-clip-text text-transparent">
                Let&apos;s Talk.
              </span>
            </h2>
            <p className="text-lg text-[#6B7280] mb-8 leading-relaxed">
              Our team is here to help you find the perfect plan for your business. 
              Reach out and we&apos;ll get back to you within a few hours.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-[#00C9A7] to-[#1C6EA4]">
                  <Mail className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-[#0B3C5D]">Email</p>
                  <p className="text-[#6B7280]">hello@genesisaipro.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-[#00C9A7] to-[#1C6EA4]">
                  <Phone className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-[#0B3C5D]">Call Us Now</p>
                  <a href="tel:+12125552368" className="text-[#00C9A7] hover-[#00B4D8] font-medium transition-colors">
                    (212) 555-2368
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-[#00C9A7] to-[#1C6EA4]">
                  <MapPin className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-[#0B3C5D]">Office</p>
                  <p className="text-[#6B7280]">Serving Local Businesses Nationwide</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Contact Form */}
          <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100">
            <h3 className="text-xl font-semibold text-[#0B3C5D] mb-6">Send Us a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                    First Name
                  </label>
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    placeholder="John"
                    required
                    className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                  />
                </div>
                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                    Last Name
                  </label>
                  <input
                    type="text"
                    id="lastName"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    placeholder="Smith"
                    required
                    className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@business.com"
                  required
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Phone <span className="text-gray-400">(optional)</span>
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="(555) 123-4567"
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Tell us about your business and how we can help..."
                  rows={4}
                  required
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder-gray-400 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting || isSuccess}
                className="w-full rounded-xl bg-gradient-to-r from-[#00C9A7] to-[#1C6EA4] py-3.5 font-semibold text-white shadow-lg shadow-[#00C9A7]/25 transition-all hover-xl hover-[#00C9A7]/30 hover:-translate-y-0.5 disabled-70 disabled-not-allowed disabled-y-0 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Sending...
                  </>
                ) ? (
                  <>
                    <CheckCircle className="h-5 w-5" />
                    Message Sent!
                  </>
                ) (
                  "Send Message"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
