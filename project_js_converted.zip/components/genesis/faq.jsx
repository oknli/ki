"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

const faqs = [
  {
    question"How long does setup take?",
    answer"Most businesses are up and running within 24 hours. Our team handles the technical setup, including phone number porting and email integration, so you can focus on your business.",
  },
  {
    question"Can I keep my existing business phone number?",
    answer"Absolutely! We can port your existing business phone number to Genesis AI Pro at no additional cost. The process typically takes 1-3 business days.",
  },
  {
    question"How does the AI know about my business?",
    answer"During onboarding, we customize the AI with your business information, services, pricing, and FAQs. The AI learns your brand voice and can answer questions specific to your business.",
  },
  {
    question"What happens when the AI can't answer a question?",
    answer"The AI seamlessly hands off to a human team member when needed. You can set custom rules for when escalation should occur, and all conversations are logged for training.",
  },
  {
    question"Can I try it before committing?",
    answer"Yes! All plans include a 14-day free trial with full access to all features. No credit card required to start.",
  },
  {
    question"Do you offer discounts for annual billing?",
    answer"Yes, you save 20% when you choose annual billing. This applies to all plans - Starter, Professional, and Enterprise.",
  },
  {
    question"Is my data secure?",
    answer"Security is our top priority. We use 256-bit SSL encryption, are SOC 2 compliant, and never share your data with third parties. All data is stored in secure, US-based data centers.",
  },
  {
    question"Can I integrate with my existing tools?",
    answer"Yes! We integrate with popular CRMs, calendars, and business tools including Salesforce, HubSpot, Google Calendar, Outlook, and many more. API access is available on Professional and Enterprise plans.",
  },
]

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <section id="faq" className="bg-white py-20 lg-28">
      <div className="mx-auto max-w-3xl px-4 sm-6 lg-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm-4xl lg-5xl font-bold text-[#0B3C5D] mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-[#6B7280]">
            Everything you need to know about Genesis AI Pro
          </p>
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-xl border border-gray-200 overflow-hidden transition-all hover-[#00C9A7]/50"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null )}
                className="w-full flex items-center justify-between p-5 text-left"
              >
                <span className="font-semibold text-[#0B3C5D] pr-4">{faq.question}</span>
                <ChevronDown
                  className={`h-5 w-5 text-[#6B7280] shrink-0 transition-transform ${
                    openIndex === index ? "rotate-180" ""
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? "max-h-48" "max-h-0"
                }`}
              >
                <p className="px-5 pb-5 text-[#6B7280] leading-relaxed">
                  {faq.answer}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
