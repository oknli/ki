"use client"

import { useState } from "react"
import { Check, Phone, MessageSquare, Loader2 } from "lucide-react"
import { toast } from "sonner"

export function Hero() {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return

    setIsSubmitting(true)

    try {
      const res = await fetch("/api/subscribe", {
        method"POST",
        headers"Content-Type""application/json" },
        body.stringify({ email }),
      })

      const data = await res.json()

      if (!res.ok) {
        toast.error(data.error || "Failed to subscribe")
        return
      }

      toast.success(data.message)
      setEmail("")
    } catch {
      toast.error("Something went wrong. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <section className="relative min-h-screen bg-gradient-to-br from-[#0B3C5D] via-[#0F4C75] to-[#1C6EA4] pt-24 pb-16 overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-[#00C9A7]/10 blur-3xl" />
        <div className="absolute top-1/2 -left-40 h-96 w-96 rounded-full bg-[#1C6EA4]/20 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm-6 lg-8">
        <div className="grid lg-cols-2 gap-12 lg-8 items-center">
          {/* Left Content */}
          <div className="text-center lg-left">
            {/* Badge */}
            <div className="inline-flex items-center rounded-full bg-white/10 px-4 py-1.5 text-sm font-medium text-white/90 backdrop-blur-sm mb-6">
              AI-Powered Communication Platform
            </div>

            {/* Main Heading */}
            <h1 className="text-4xl sm-5xl lg-6xl font-bold text-white leading-tight mb-6">
              Never Miss
              <br />
              <span className="bg-gradient-to-r from-[#00C9A7] to-[#4FD1C5] bg-clip-text text-transparent">
                Another Customer
              </span>
              <br />
              Again
            </h1>

            {/* Subtext */}
            <p className="text-lg text-white/70 max-w-xl mx-auto lg-0 mb-8 leading-relaxed">
              Manage all your calls, emails, texts, and web chats in one unified inbox. 
              Automatically book appointments to your calendar. Built for local small businesses.
            </p>

            {/* Email Input + CTA */}
            <form onSubmit={handleSubmit} className="flex flex-col sm-row gap-3 max-w-md mx-auto lg-0 mb-4">
              <input
                type="email"
                placeholder="Enter your business email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 rounded-xl bg-white/10 backdrop-blur-sm px-5 py-3.5 text-white placeholder-white/50 border border-white/20 focus-[#00C9A7] focus-none focus-2 focus-[#00C9A7]/20 transition-all"
              />
              <button
                type="submit"
                disabled={isSubmitting}
                className="rounded-xl bg-gradient-to-r from-[#00C9A7] to-[#00B4D8] px-6 py-3.5 font-semibold text-white shadow-lg shadow-[#00C9A7]/25 transition-all hover-xl hover-[#00C9A7]/30 hover:-translate-y-0.5 disabled-70 disabled-not-allowed disabled-y-0 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) (
                  "Start Free Trial"
                )}
              </button>
            </form>

            {/* Call Now Button */}
            <a
              href="tel:+12125552368"
              className="inline-block max-w-md mx-auto lg-0 mb-6 rounded-xl bg-white/20 hover-white/30 text-white font-semibold py-3 px-6 border border-white/30 transition-all flex items-center justify-center gap-2 w-full sm-auto"
            >
              <Phone className="h-4 w-4" />
              Call Now(212) 555-2368
            </a>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center lg-start gap-4 text-sm text-white/70">
              <span className="flex items-center gap-1.5">
                <Check className="h-4 w-4 text-[#00C9A7]" />
                No credit card required
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="h-4 w-4 text-[#00C9A7]" />
                14-day free trial
              </span>
              <span className="flex items-center gap-1.5">
                <Check className="h-4 w-4 text-[#00C9A7]" />
                Cancel anytime
              </span>
            </div>
          </div>

          {/* Right Visual Panel */}
          <div className="relative lg-8">
            {/* Main Dashboard Mockup */}
            <div className="relative rounded-2xl bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl p-4 shadow-2xl border border-white/20 transform lg-2 hover-0 transition-transform duration-500">
              <div className="rounded-xl bg-[#0a1628] p-4 aspect-[4/3]">
                {/* Mock Dashboard Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-red-400" />
                    <div className="h-3 w-3 rounded-full bg-yellow-400" />
                    <div className="h-3 w-3 rounded-full bg-green-400" />
                  </div>
                  <div className="h-2 w-24 rounded bg-white/20" />
                </div>
                
                {/* Mock Dashboard Content */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="rounded-lg bg-white/5 p-3">
                    <div className="h-2 w-12 rounded bg-[#00C9A7]/50 mb-2" />
                    <div className="h-6 w-8 rounded bg-white/20" />
                  </div>
                  <div className="rounded-lg bg-white/5 p-3">
                    <div className="h-2 w-10 rounded bg-blue-400/50 mb-2" />
                    <div className="h-6 w-10 rounded bg-white/20" />
                  </div>
                  <div className="rounded-lg bg-white/5 p-3">
                    <div className="h-2 w-14 rounded bg-purple-400/50 mb-2" />
                    <div className="h-6 w-6 rounded bg-white/20" />
                  </div>
                </div>

                {/* Mock Message List */}
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-3 rounded-lg bg-white/5 p-3">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-br from-[#00C9A7]/30 to-blue-400/30" />
                      <div className="flex-1">
                        <div className="h-2 w-20 rounded bg-white/30 mb-1.5" />
                        <div className="h-2 w-32 rounded bg-white/15" />
                      </div>
                      <div className="h-2 w-10 rounded bg-white/10" />
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Floating Card 1 - New Call */}
            <div className="absolute -left-4 top-1/4 rounded-xl bg-white/95 backdrop-blur-lg p-4 shadow-xl border border-white/50 transform -rotate-3 hover-0 transition-transform duration-300 animate-float">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#00C9A7] to-[#00B4D8]">
                  <Phone className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-[#0B3C5D]">New Call</p>
                  <p className="text-sm text-[#6B7280]">Auto-booked to calendar</p>
                </div>
              </div>
            </div>

            {/* Floating Card 2 - Web Chat */}
            <div className="absolute -right-4 bottom-1/4 rounded-xl bg-white/95 backdrop-blur-lg p-4 shadow-xl border border-white/50 transform rotate-3 hover-0 transition-transform duration-300 animate-float-delayed">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#1C6EA4] to-[#0B3C5D]">
                  <MessageSquare className="h-5 w-5 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-[#0B3C5D]">Web Chat</p>
                  <p className="text-sm text-[#6B7280]">AI responding now...</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CSS for floating animation */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform(0) rotate(-3deg); }
          50% { transform(-10px) rotate(-3deg); }
        }
        @keyframes float-delayed {
          0%, 100% { transform(0) rotate(3deg); }
          50% { transform(-10px) rotate(3deg); }
        }
        .animate-float {
          animation-in-out infinite;
        }
        .animate-float-delayed {
          animation-delayed 4s ease-in-out infinite 1s;
        }
      `}</style>
    </section>
  )
}
