"use client"

import { useState } from "react"
import { Star } from "lucide-react"

const testimonials = [
  {
    quote"Before Genesis AI Pro, we were missing 40% of our calls. Now we capture every lead and our revenue jumped 35% in just three months.",
    name"Mike Rodriguez",
    role"Owner, Rodriguez Auto Repair",
    avatar"MR",
  },
  {
    quote"The unified inbox is a game-changer. We can see all patient communications in one place and our satisfaction scores are through the roof.",
    name"Sarah Chen",
    role"Director, Bright Smile Dental",
    avatar"SC",
  },
  {
    quote"I was skeptical about AI handling our calls, but the quality is incredible. It&apos;s like having a full-time receptionist working 24/7.",
    name"James Thompson",
    role"Founder, Thompson Plumbing",
    avatar"JT",
  },
]

const industries = [
  "Auto Repair",
  "Dental Offices",
  "Plumbing",
  "Day Spas",
  "Law Firms",
  "Fitness Studios",
  "HVAC",
  "Daycare",
  "Restaurants",
  "Real Estate",
]

export function Testimonials() {
  const [activeIndex, setActiveIndex] = useState(0)

  return (
    <section id="testimonials" className="bg-white py-20 lg-28">
      <div className="mx-auto max-w-7xl px-4 sm-6 lg-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center rounded-full bg-[#1C6EA4]/10 px-4 py-1.5 text-sm font-medium text-[#1C6EA4] mb-4">
            Trusted by Local Businesses
          </div>
          <h2 className="text-3xl sm-4xl lg-5xl font-bold text-[#0B3C5D] mb-4">
            Real Results from{" "}
            <span className="bg-gradient-to-r from-[#1C6EA4] to-[#00C9A7] bg-clip-text text-transparent">
              Real Businesses
            </span>
          </h2>
          <p className="text-lg text-[#6B7280] max-w-2xl mx-auto leading-relaxed">
            See how local businesses like yours are transforming their customer 
            communications and growing revenue.
          </p>
        </div>

        {/* Testimonial Cards */}
        <div className="grid md-cols-3 gap-6 mb-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.name}
              className={`bg-white rounded-2xl p-6 shadow-lg border transition-all duration-300 cursor-pointer ${
                activeIndex === index
                  ? "border-[#00C9A7] shadow-xl scale-[1.02]"
                  "border-gray-100 hover-[#00C9A7]/50"
              }`}
              onClick={() => setActiveIndex(index)}
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-[#F59E0B] text-[#F59E0B]" />
                ))}
              </div>

              {/* Quote */}
              <p className="text-[#0B3C5D] mb-6 leading-relaxed">
                &ldquo;{testimonial.quote}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-[#1C6EA4] to-[#00C9A7] text-white font-semibold">
                  {testimonial.avatar}
                </div>
                <div>
                  <p className="font-semibold text-[#0B3C5D]">{testimonial.name}</p>
                  <p className="text-sm text-[#6B7280]">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Slider Dots */}
        <div className="flex justify-center gap-2 mb-12">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveIndex(index)}
              className={`h-2 rounded-full transition-all ${
                activeIndex === index
                  ? "w-8 bg-[#00C9A7]"
                  "w-2 bg-[#1C6EA4]/30 hover-[#1C6EA4]/50"
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>

        {/* Industry Tags */}
        <div className="flex flex-wrap justify-center gap-3">
          {industries.map((industry) => (
            <span
              key={industry}
              className="rounded-full bg-[#F7F9FB] px-4 py-2 text-sm font-medium text-[#0B3C5D] border border-gray-200 hover-[#00C9A7] hover-[#00C9A7]/5 transition-colors cursor-pointer"
            >
              {industry}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
