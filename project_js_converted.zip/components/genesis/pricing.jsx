"use client"

import { useState } from "react"
import { Check, X } from "lucide-react"

const plans = [
  {
    name"Starter",
    description"Perfect for solo operators and new businesses",
    monthlyPrice"1 Business Phone Number", included"Email Integration (1 account)", included"SMS/Text Messaging (500/mo)", included"Web Chat Widget", included"Calendar Booking", included"AI Auto-Responses", included"Unified Inbox", included"Basic Analytics", included"Multi-user Access", included"Custom AI Training", included"API Access", included"Priority Support", included"Professional",
    description"Ideal for growing businesses with a team",
    monthlyPrice"3 Business Phone Numbers", included"Email Integration (5 accounts)", included"SMS/Text Messaging (2,000/mo)", included"Web Chat Widget (Branded)", included"Calendar Booking + Reminders", included"Advanced AI Auto-Responses", included"Unified Inbox + Team Assignment", included"Advanced Analytics & Reports", included"Up to 5 Team Members", included"Custom AI Training", included"API Access", included"Dedicated Account Manager", included"Enterprise",
    description"For established businesses needing full power",
    monthlyPrice"Unlimited Phone Numbers", included"Unlimited Email Accounts", included"Unlimited SMS/Text", included"Multi-site Web Chat", included"Advanced Booking + Workflows", included"Enterprise AI with Custom Models", included"Unified Inbox + Smart Routing", included"Custom Reports & Dashboards", included"Unlimited Team Members", included"Full Custom AI Training", included"Full API Access + Webhooks", included"Dedicated Account Manager", included() {
  const [isYearly, setIsYearly] = useState(true)

  return (
    <section id="pricing" className="bg-gradient-to-br from-[#0B3C5D] via-[#0F4C75] to-[#1C6EA4] py-20 lg-28">
      <div className="mx-auto max-w-7xl px-4 sm-6 lg-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm-4xl lg-5xl font-bold text-white mb-4">
            Simple,{" "}
            <span className="bg-gradient-to-r from-[#00C9A7] to-[#4FD1C5] bg-clip-text text-transparent">
              Transparent Pricing
            </span>
          </h2>
          <p className="text-lg text-white/70 max-w-2xl mx-auto leading-relaxed mb-8">
            Choose the plan that fits your business. All plans include a 14-day free trial. 
            No credit card required. Cancel anytime.
          </p>

          {/* Billing Toggle */}
          <div className="inline-flex items-center bg-white/10 rounded-full p-1">
            <button
              onClick={() => setIsYearly(false)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                !isYearly
                  ? "bg-white text-[#0B3C5D]"
                  "text-white/70 hover-white"
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setIsYearly(true)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 ${
                isYearly
                  ? "bg-white text-[#0B3C5D]"
                  "text-white/70 hover-white"
              }`}
            >
              Annual
              {isYearly && (
                <span className="bg-[#00C9A7] text-white text-xs px-2 py-0.5 rounded-full">
                  Save 20%
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid lg-cols-3 gap-8">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative bg-white rounded-2xl p-8 ${
                plan.popular
                  ? "ring-2 ring-[#00C9A7] shadow-2xl scale-105"
                  "shadow-xl"
              }`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-[#00C9A7] to-[#1C6EA4] text-white text-sm font-semibold px-4 py-1 rounded-full">
                  Most Popular
                </div>
              )}

              {/* Plan Info */}
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-[#0B3C5D] mb-2">{plan.name}</h3>
                <p className="text-[#6B7280] text-sm mb-4">{plan.description}</p>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-4xl font-bold text-[#0B3C5D]">
                    ${isYearly ? plan.yearlyPrice .monthlyPrice}
                  </span>
                  <span className="text-[#6B7280]">/month</span>
                </div>
                {isYearly && (
                  <p className="text-sm text-[#00C9A7] mt-1">
                    Billed annually (${(isYearly ? plan.yearlyPrice .monthlyPrice) * 12}/year)
                  </p>
                )}
              </div>

              {/* CTA Button */}
              <button
                className={`w-full py-3 rounded-xl font-semibold transition-all mb-8 ${
                  plan.popular
                    ? "bg-gradient-to-r from-[#00C9A7] to-[#1C6EA4] text-white hover-lg"
                    "bg-gray-100 text-[#0B3C5D] hover-gray-200"
                }`}
              >
                Start 14-Day Free Trial
              </button>

              {/* Features */}
              <ul className="space-y-3">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-3">
                    {feature.included ? (
                      <Check className="h-5 w-5 text-[#00C9A7] shrink-0 mt-0.5" />
                    ) (
                      <X className="h-5 w-5 text-red-400 shrink-0 mt-0.5" />
                    )}
                    <span className={feature.included ? "text-[#0B3C5D]" "text-[#9CA3AF]"}>
                      {feature.text}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
