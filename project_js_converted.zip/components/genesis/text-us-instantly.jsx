'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { MessageCircle, Send, Phone } from 'lucide-react'
import { toast } from 'sonner'

export function TextUsInstantly() {
  const [formData, setFormData] = useState({ phone'', message'' })
  const [isLoading, setIsLoading] = useState(false)

  const handleInputChange = (e.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]))
  }

  const handleSubmit = async (e.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch('/api/send-sms', {
        method'POST',
        headers'Content-Type''application/json' },
        body.stringify({
          phone.phone.startsWith('+') ? formData.phone `+1${formData.phone.replace(/\D/g, '')}`,
          message.message,
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        toast.error(error.message || 'Failed to send message')
        setIsLoading(false)
        return
      }

      toast.success('Message sent! We\'ll reply shortly.')
      setFormData({ phone'', message'' })
    } catch (error) {
      toast.error('Failed to send message. Please try again.')
      console.error('SMS error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <section className="py-16 md-24 bg-gradient-to-b from-background to-secondary/20">
      <div className="max-w-4xl mx-auto px-4 sm-6 lg-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <MessageCircle className="w-8 h-8 text-cyan-500" />
            <h2 className="text-3xl md-4xl font-bold text-balance">Text Us Instantly</h2>
          </div>
          <p className="text-lg text-foreground/70">Send us a message and get a quick response from our team</p>
        </div>

        <div className="bg-card rounded-2xl border border-cyan-500/20 p-8 shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Phone Number Input */}
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-foreground mb-2">
                Your Phone Number
              </label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                placeholder="+1 (212) 555-2368"
                value={formData.phone}
                onChange={handleInputChange}
                required
                className="w-full"
              />
              <p className="text-xs text-foreground/50 mt-1">We&apos;ll use this to reply via SMS</p>
            </div>

            {/* Message Input */}
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-foreground mb-2">
                Your Message
              </label>
              <textarea
                id="message"
                name="message"
                placeholder="Tell us how we can help you with your communication needs..."
                value={formData.message}
                onChange={handleInputChange}
                required
                rows={4}
                maxLength={1600}
                className="w-full rounded-lg border border-input bg-background px-4 py-2 text-sm placeholder-foreground/50 focus-none focus-2 focus-cyan-500 focus-transparent resize-none"
              />
              <p className="text-xs text-foreground/50 mt-1">
                {formData.message.length} / 1600 characters
              </p>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading || !formData.phone || !formData.message}
              className="w-full bg-gradient-to-r from-primary to-cyan-500 hover-primary/90 hover-cyan-600 disabled-50 disabled-not-allowed text-white font-semibold py-3 rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              {isLoading ? 'Sending...' 'Send Message'}
            </button>

            {/* Call Button */}
            <a
              href="tel:+12125552368"
              className="block w-full bg-secondary hover-secondary/80 text-foreground font-semibold py-3 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 border border-secondary/50"
            >
              <Phone className="w-4 h-4" />
              Call Us Now
            </a>
          </form>
        </div>

        {/* Trust Indicators */}
        <div className="grid grid-cols-2 md-cols-3 gap-4 mt-12">
          <div className="text-center">
            <p className="text-2xl font-bold text-cyan-500">24/7</p>
            <p className="text-sm text-foreground/60">Available</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-cyan-500">&lt;5 min</p>
            <p className="text-sm text-foreground/60">Response Time</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-cyan-500">100%</p>
            <p className="text-sm text-foreground/60">Secure</p>
          </div>
        </div>
      </div>
    </section>
  )
}
