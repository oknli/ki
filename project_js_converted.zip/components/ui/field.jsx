'use client'

import { useMemo } from 'react'
import { cva, type VariantProps } from 'class-variance-authority'

import { cn } from '@/lib/utils'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'

function FieldSet({ className, ...props }.ComponentProps<'fieldset'>) {
  return (
    <fieldset
      data-slot="field-set"
      className={cn(
        'flex flex-col gap-6',
        'has-[>[data-slot=checkbox-group]]-3 has-[>[data-slot=radio-group]]-3',
        className,
      )}
      {...props}
    />
  )
}

function FieldLegend({
  className,
  variant = 'legend',
  ...props
}.ComponentProps<'legend'> & { variant?'legend' | 'label' }) {
  return (
    <legend
      data-slot="field-legend"
      data-variant={variant}
      className={cn(
        'mb-3 font-medium',
        'data-[variant=legend]-base',
        'data-[variant=label]-sm',
        className,
      )}
      {...props}
    />
  )
}

function FieldGroup({ className, ...props }.ComponentProps<'div'>) {
  return (
    <div
      data-slot="field-group"
      className={cn(
        'group/field-group @container/field-group flex w-full flex-col gap-7 data-[slot=checkbox-group]-3 [&>[data-slot=field-group]]-4',
        className,
      )}
      {...props}
    />
  )
}

const fieldVariants = cva(
  'group/field flex w-full gap-3 data-[invalid=true]-destructive',
  {
    variants'flex-col [&>*]-full [&>.sr-only]-auto'],
        horizontal'flex-row items-center',
          '[&>[data-slot=field-label]]-auto',
          'has-[>[data-slot=field-content]]-start has-[>[data-slot=field-content]]&>[role=checkbox],[role=radio]]-px',
        ],
        responsive'flex-col [&>*]-full [&>.sr-only]-auto @md/field-group-row @md/field-group-center @md/field-group&>*]-auto',
          '@md/field-group&>[data-slot=field-label]]-auto',
          '@md/field-group-[>[data-slot=field-content]]-start @md/field-group-[>[data-slot=field-content]]&>[role=checkbox],[role=radio]]-px',
        ],
      },
    },
    defaultVariants'vertical',
    },
  },
)

function Field({
  className,
  orientation = 'vertical',
  ...props
}.ComponentProps<'div'> & VariantProps<typeof fieldVariants>) {
  return (
    <div
      role="group"
      data-slot="field"
      data-orientation={orientation}
      className={cn(fieldVariants({ orientation }), className)}
      {...props}
    />
  )
}

function FieldContent({ className, ...props }.ComponentProps<'div'>) {
  return (
    <div
      data-slot="field-content"
      className={cn(
        'group/field-content flex flex-1 flex-col gap-1.5 leading-snug',
        className,
      )}
      {...props}
    />
  )
}

function FieldLabel({
  className,
  ...props
}.ComponentProps<typeof Label>) {
  return (
    <Label
      data-slot="field-label"
      className={cn(
        'group/field-label peer/field-label flex w-fit gap-2 leading-snug group-data-[disabled=true]/field-50',
        'has-[>[data-slot=field]]-full has-[>[data-slot=field]]-col has-[>[data-slot=field]]-md has-[>[data-slot=field]]&>*]-[slot=field]-4',
        'has-data-[state=checked]-primary/5 has-data-[state=checked]-primary dark-data-[state=checked]-primary/10',
        className,
      )}
      {...props}
    />
  )
}

function FieldTitle({ className, ...props }.ComponentProps<'div'>) {
  return (
    <div
      data-slot="field-label"
      className={cn(
        'flex w-fit items-center gap-2 text-sm leading-snug font-medium group-data-[disabled=true]/field-50',
        className,
      )}
      {...props}
    />
  )
}

function FieldDescription({ className, ...props }.ComponentProps<'p'>) {
  return (
    <p
      data-slot="field-description"
      className={cn(
        'text-muted-foreground text-sm leading-normal font-normal group-has-[[data-orientation=horizontal]]/field-balance',
        'last-0 nth-last-2:-mt-1 [[data-variant=legend]+&]:-mt-1.5',
        '[&>a-primary [&>a]&>a]-offset-4',
        className,
      )}
      {...props}
    />
  )
}

function FieldSeparator({
  children,
  className,
  ...props
}.ComponentProps<'div'> & {
  children?.ReactNode
}) {
  return (
    <div
      data-slot="field-separator"
      data-content={!!children}
      className={cn(
        'relative -my-2 h-5 text-sm group-data-[variant=outline]/field-group:-mb-2',
        className,
      )}
      {...props}
    >
      <Separator className="absolute inset-0 top-1/2" />
      {children && (
        <span
          className="bg-background text-muted-foreground relative mx-auto block w-fit px-2"
          data-slot="field-separator-content"
        >
          {children}
        </span>
      )}
    </div>
  )
}

function FieldError({
  className,
  children,
  errors,
  ...props
}.ComponentProps<'div'> & {
  errors??) {
  const content = useMemo(() => {
    if (children) {
      return children
    }

    if (!errors) {
      return null
    }

    if (errors.length === 1 && errors[0]?.message) {
      return errors[0].message
    }

    return (
      <ul className="ml-4 flex list-disc flex-col gap-1">
        {errors.map(
          (error, index) =>
            error?.message && <li key={index}>{error.message}</li>,
        )}
      </ul>
    )
  }, [children, errors])

  if (!content) {
    return null
  }

  return (
    <div
      role="alert"
      data-slot="field-error"
      className={cn('text-destructive text-sm font-normal', className)}
      {...props}
    >
      {content}
    </div>
  )
}

export {
  Field,
  FieldLabel,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLegend,
  FieldSeparator,
  FieldSet,
  FieldContent,
  FieldTitle,
}
