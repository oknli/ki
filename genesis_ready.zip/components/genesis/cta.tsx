"use client"

import { useState } from "react"
import { Shield, CreditCard, Headphones, Loader2 } from "lucide-react"
import { toast } from "sonner"

export function CTA() {
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return

    setIsSubmitting(true)

    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      })

      const data = await res.json()

      if (!res.ok) {
        toast.error(data.error || "Failed to subscribe")
        return
      }

      toast.success(data.message)
      setEmail("")
    } catch {
      toast.error("Something went wrong. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <section className="bg-gradient-to-br from-[#0B3C5D] via-[#0F4C75] to-[#1C6EA4] py-20 lg:py-28 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-[#00C9A7]/10 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-[#1C6EA4]/20 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
        {/* Badge */}
        <div className="inline-flex items-center rounded-full bg-[#00C9A7]/20 px-4 py-1.5 text-sm font-medium text-[#00C9A7] mb-6">
          Limited Time: 14-Day Free Trial
        </div>

        {/* Heading */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 text-balance">
          Ready to Stop Losing Customers to Missed Messages?
        </h2>

        {/* Subtext */}
        <p className="text-lg text-white/70 max-w-2xl mx-auto mb-10 leading-relaxed">
          Join hundreds of local businesses already using Genesis AI Pro to capture every lead, 
          respond instantly, and book more appointments — all on autopilot.
        </p>

        {/* Email Input + CTA */}
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto mb-10">
          <input
            type="email"
            placeholder="Enter your business email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="flex-1 rounded-xl bg-white/10 backdrop-blur-sm px-5 py-3.5 text-white placeholder:text-white/50 border border-white/20 focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all"
          />
          <button
            type="submit"
            disabled={isSubmitting}
            className="rounded-xl bg-gradient-to-r from-[#00C9A7] to-[#00B4D8] px-6 py-3.5 font-semibold text-white shadow-lg shadow-[#00C9A7]/25 transition-all hover:shadow-xl hover:shadow-[#00C9A7]/30 hover:-translate-y-0.5 disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:translate-y-0 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Submitting...
              </>
            ) : (
              "Start Free Trial"
            )}
          </button>
        </form>

        {/* Trust Line */}
        <div className="flex flex-wrap justify-center gap-6 text-sm text-white/60">
          <span className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            256-bit SSL Encryption
          </span>
          <span className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            No credit card required
          </span>
          <span className="flex items-center gap-2">
            <Headphones className="h-4 w-4" />
            24/7 Support
          </span>
        </div>
      </div>
    </section>
  )
}
