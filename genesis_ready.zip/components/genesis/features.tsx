import { Phone, Mail, MessageSquare, MessagesSquare, Calendar, Inbox } from "lucide-react"

const features = [
  {
    icon: Phone,
    title: "Call Management",
    description: "AI-powered call routing, recording, transcription, voicemail-to-text, follow-ups",
    color: "from-[#00C9A7] to-[#00B4D8]",
  },
  {
    icon: Mail,
    title: "Email Integration",
    description: "Sync with Gmail/Outlook, AI categorizes and drafts responses",
    color: "from-[#1C6EA4] to-[#0B3C5D]",
  },
  {
    icon: MessageSquare,
    title: "SMS & Text Messaging",
    description: "Two-way texting, reminders, promotions, follow-ups",
    color: "from-[#F59E0B] to-[#D97706]",
  },
  {
    icon: MessagesSquare,
    title: "Live Web Chat",
    description: "24/7 chatbot, human handoff support",
    color: "from-[#8B5CF6] to-[#7C3AED]",
  },
  {
    icon: Calendar,
    title: "Calendar Booking",
    description: "Syncs calendars, auto confirmations, reminders",
    color: "from-[#EC4899] to-[#DB2777]",
  },
  {
    icon: Inbox,
    title: "Unified Inbox",
    description: "All conversations in one place, full customer history",
    color: "from-[#00C9A7] to-[#1C6EA4]",
  },
]

export function Features() {
  return (
    <section id="features" className="bg-[#F7F9FB] py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center rounded-full bg-[#1C6EA4]/10 px-4 py-1.5 text-sm font-medium text-[#1C6EA4] mb-4">
            All-In-One Platform
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0B3C5D] mb-4">
            Every Channel.{" "}
            <span className="bg-gradient-to-r from-[#1C6EA4] to-[#00C9A7] bg-clip-text text-transparent">
              One Dashboard.
            </span>
          </h2>
          <p className="text-lg text-[#6B7280] max-w-2xl mx-auto leading-relaxed">
            Stop juggling between apps. Genesis AI Pro brings all your customer communications 
            together so you can focus on what matters — growing your business.
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-[#00C9A7]/30 hover:-translate-y-1"
            >
              {/* Icon */}
              <div className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${feature.color} mb-4`}>
                <feature.icon className="h-6 w-6 text-white" />
              </div>
              
              {/* Content */}
              <h3 className="text-xl font-semibold text-[#0B3C5D] mb-2 group-hover:text-[#1C6EA4] transition-colors">
                {feature.title}
              </h3>
              <p className="text-[#6B7280] leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
