"use client"

import { useState } from "react"
import { Menu, X } from "lucide-react"
import { useRouter } from "next/navigation"
import { BookDemoModal } from "./book-demo-modal"

export function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [demoModalOpen, setDemoModalOpen] = useState(false)
  const router = useRouter()

  const navLinks = [
    { name: "Features", href: "#features" },
    { name: "How It Works", href: "#how-it-works" },
    { name: "Testimonials", href: "#testimonials" },
    { name: "Pricing", href: "#pricing" },
    { name: "Agent Chat", href: "#agent-chat", hasIndicator: true },
  ]

  const handleSignIn = () => {
    router.push("/login")
  }

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0B3C5D]/95 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#00C9A7] to-[#1C6EA4]">
                <svg className="h-5 w-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                </svg>
              </div>
              <span className="text-lg font-bold text-white">GENESIS AI PRO</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex md:items-center md:gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="relative flex items-center gap-1.5 text-sm font-medium text-white/90 transition-colors hover:text-white"
                >
                  {link.hasIndicator && (
                    <span className="h-2 w-2 rounded-full bg-green-400" />
                  )}
                  {link.name}
                </a>
              ))}
            </div>

            {/* Desktop CTA Buttons */}
            <div className="hidden md:flex md:items-center md:gap-3">
              <button
                onClick={() => setDemoModalOpen(true)}
                className="rounded-full bg-gradient-to-r from-[#00C9A7] to-[#1C6EA4] px-5 py-2 text-sm font-semibold text-white transition-all hover:opacity-90 hover:shadow-lg"
              >
                Book a Demo
              </button>
              <button
                onClick={handleSignIn}
                className="rounded-full border border-white/30 px-5 py-2 text-sm font-semibold text-white transition-all hover:border-white/50 hover:bg-white/10"
              >
                Sign In
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden rounded-lg p-2 text-white hover:bg-white/10"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-white/10 bg-[#0B3C5D]">
            <div className="px-4 py-4 space-y-3">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="flex items-center gap-2 text-sm font-medium text-white/90 py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {link.hasIndicator && (
                    <span className="h-2 w-2 rounded-full bg-green-400" />
                  )}
                  {link.name}
                </a>
              ))}
              <div className="flex flex-col gap-3 pt-4 border-t border-white/10">
                <button
                  onClick={() => {
                    setDemoModalOpen(true)
                    setMobileMenuOpen(false)
                  }}
                  className="rounded-full bg-gradient-to-r from-[#00C9A7] to-[#1C6EA4] px-5 py-2.5 text-sm font-semibold text-white"
                >
                  Book a Demo
                </button>
                <button
                  onClick={() => {
                    handleSignIn()
                    setMobileMenuOpen(false)
                  }}
                  className="rounded-full border border-white/30 px-5 py-2.5 text-sm font-semibold text-white"
                >
                  Sign In
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      <BookDemoModal open={demoModalOpen} onClose={() => setDemoModalOpen(false)} />
    </>
  )
}
