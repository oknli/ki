"use client"

import { useEffect, useState } from "react"
import { X, Calendar, Loader2, CheckCircle } from "lucide-react"
import { toast } from "sonner"

interface BookDemoModalProps {
  open: boolean
  onClose: () => void
}

export function BookDemoModal({ open, onClose }: BookDemoModalProps) {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    preferredDate: "",
    preferredTime: "",
    notes: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  // Handle ESC key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }
    if (open) {
      document.addEventListener("keydown", handleEsc)
      document.body.style.overflow = "hidden"
    }
    return () => {
      document.removeEventListener("keydown", handleEsc)
      document.body.style.overflow = ""
    }
  }, [open, onClose])

  // Reset form when modal closes
  useEffect(() => {
    if (!open) {
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        company: "",
        preferredDate: "",
        preferredTime: "",
        notes: "",
      })
      setIsSuccess(false)
    }
  }, [open])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const res = await fetch("/api/book-demo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      const data = await res.json()

      if (!res.ok) {
        toast.error(data.error || "Failed to book demo")
        return
      }

      setIsSuccess(true)
      toast.success(data.message)
      
      // Close modal after success
      setTimeout(() => {
        onClose()
      }, 2000)
    } catch {
      toast.error("Something went wrong. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-[#0B3C5D]/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-lg mx-4 bg-white rounded-2xl shadow-2xl animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors z-10"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Content */}
        <div className="p-8">
          {/* Icon */}
          <div className="flex justify-center mb-6">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-[#00C9A7]/20 to-[#1C6EA4]/20">
              <Calendar className="h-8 w-8 text-[#1C6EA4]" />
            </div>
          </div>

          {/* Header */}
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-[#0B3C5D] mb-2">
              Book Your Free Demo
            </h3>
            <p className="text-[#6B7280]">
              See how Genesis AI Pro can transform your business communications
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="demo-firstName" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  First Name
                </label>
                <input
                  type="text"
                  id="demo-firstName"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  placeholder="John"
                  required
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder:text-gray-400 focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all"
                />
              </div>
              <div>
                <label htmlFor="demo-lastName" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Last Name
                </label>
                <input
                  type="text"
                  id="demo-lastName"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  placeholder="Smith"
                  required
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder:text-gray-400 focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all"
                />
              </div>
            </div>

            <div>
              <label htmlFor="demo-email" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                Email
              </label>
              <input
                type="email"
                id="demo-email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="john@mybusiness.com"
                required
                className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder:text-gray-400 focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="demo-phone" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Phone <span className="text-gray-400">(optional)</span>
                </label>
                <input
                  type="tel"
                  id="demo-phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="(555) 123-4567"
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder:text-gray-400 focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all"
                />
              </div>
              <div>
                <label htmlFor="demo-company" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Company <span className="text-gray-400">(optional)</span>
                </label>
                <input
                  type="text"
                  id="demo-company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Your Business"
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder:text-gray-400 focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="demo-date" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Preferred Date
                </label>
                <input
                  type="date"
                  id="demo-date"
                  name="preferredDate"
                  value={formData.preferredDate}
                  onChange={handleChange}
                  required
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all"
                />
              </div>
              <div>
                <label htmlFor="demo-time" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                  Preferred Time
                </label>
                <select
                  id="demo-time"
                  name="preferredTime"
                  value={formData.preferredTime}
                  onChange={handleChange}
                  required
                  className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all"
                >
                  <option value="">Select time</option>
                  <option value="9:00 AM">9:00 AM</option>
                  <option value="10:00 AM">10:00 AM</option>
                  <option value="11:00 AM">11:00 AM</option>
                  <option value="12:00 PM">12:00 PM</option>
                  <option value="1:00 PM">1:00 PM</option>
                  <option value="2:00 PM">2:00 PM</option>
                  <option value="3:00 PM">3:00 PM</option>
                  <option value="4:00 PM">4:00 PM</option>
                  <option value="5:00 PM">5:00 PM</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="demo-notes" className="block text-sm font-medium text-[#0B3C5D] mb-1.5">
                Notes <span className="text-gray-400">(optional)</span>
              </label>
              <textarea
                id="demo-notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                placeholder="Anything specific you'd like to see in the demo?"
                rows={3}
                className="w-full rounded-xl border border-gray-200 px-4 py-3 text-[#0B3C5D] placeholder:text-gray-400 focus:border-[#00C9A7] focus:outline-none focus:ring-2 focus:ring-[#00C9A7]/20 transition-all resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting || isSuccess}
              className="w-full rounded-xl bg-gradient-to-r from-[#00C9A7] to-[#1C6EA4] py-3.5 font-semibold text-white shadow-lg shadow-[#00C9A7]/25 transition-all hover:shadow-xl hover:shadow-[#00C9A7]/30 hover:-translate-y-0.5 disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:translate-y-0 mt-2 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Scheduling...
                </>
              ) : isSuccess ? (
                <>
                  <CheckCircle className="h-5 w-5" />
                  Demo Scheduled!
                </>
              ) : (
                "Schedule My Demo"
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
