# Genesis AI Pro — Combined Project

## How It Works

This project connects two parts:

### Part 1: Landing Page (Next.js)
- Root of this folder (`/`)
- The marketing site — hero, features, pricing, FAQ, etc.
- **Sign In button** in the navbar now redirects to `/login`

### Part 2: Dashboard (Vite/React — in `/saas-dashboard`)
- The authenticated dashboard app
- Routes: `/login`, `/signup`, `/dashboard`, `/dashboard/sms`, etc.

---

## Connection Flow

```
Landing Page (Next.js)
  └─ Navbar → [Sign In] button
       └─ redirects to → /login
            └─ Genesis Dashboard Login Page
                 └─ on success → /dashboard
```

---

## Color Changes (Dashboard)

The Genesis dashboard (`saas-dashboard/src/index.css`) has been updated to match
the landing page's color palette:

| Token      | Color            | Hex       |
|------------|------------------|-----------|
| Primary    | Navy             | #0B3C5D   |
| Accent     | Teal             | #00C9A7   |
| Sidebar    | Navy             | #0B3C5D   |
| Ring/Focus | Teal             | #00C9A7   |

---

## Running the Project

### Landing Page
```bash
npm install
npm run dev
# Runs on http://localhost:3000
```

### Dashboard (run separately or integrate via proxy)
```bash
cd saas-dashboard
npm install
PORT=3001 BASE_PATH=/ npm run dev
# Runs on http://localhost:3001
```

### For production — configure Next.js to proxy `/login` and `/dashboard` routes
to the Vite dashboard app, or deploy both and link via absolute URL.
