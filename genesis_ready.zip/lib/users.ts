import fs from 'fs'
import path from 'path'

// Use a JSON file for persistence (simple and works immediately)
const USERS_FILE = path.join(process.cwd(), '.data', 'users.json')

// Ensure directory exists
function ensureDataDir() {
  const dir = path.dirname(USERS_FILE)
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true })
  }
}

// Read users from file
function loadUsers() {
  ensureDataDir()
  try {
    if (fs.existsSync(USERS_FILE)) {
      const data = fs.readFileSync(USERS_FILE, 'utf-8')
      return JSON.parse(data)
    }
  } catch (error) {
    console.error('[users] Error loading users:', error)
  }
  return []
}

// Write users to file
function saveUsers(users: any[]) {
  try {
    ensureDataDir()
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2))
  } catch (error) {
    console.error('[users] Error saving users:', error)
  }
}

export function createUser(name: string, email: string, password: string) {
  const users = loadUsers()
  const userId = Math.random().toString(36).substring(7)
  const newUser = {
    id: userId,
    name,
    email,
    password,
  }
  users.push(newUser)
  saveUsers(users)
  return newUser
}

export function findUserByEmail(email: string) {
  const users = loadUsers()
  return users.find(u => u.email === email)
}

export function getUsers() {
  return loadUsers()
}
