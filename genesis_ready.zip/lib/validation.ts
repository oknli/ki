import { z } from 'zod'

// Contact form validation
export const contactSchema = z.object({
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().optional(),
  message: z.string().min(10, 'Message must be at least 10 characters'),
})

export type ContactFormData = z.infer<typeof contactSchema>

// Book demo form validation
export const bookDemoSchema = z.object({
  firstName: z.string().min(2, 'First name must be at least 2 characters'),
  lastName: z.string().min(2, 'Last name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().optional(),
  company: z.string().optional(),
  preferredDate: z.string().min(1, 'Please select a preferred date'),
  preferredTime: z.string().min(1, 'Please select a preferred time'),
  notes: z.string().optional(),
})

export type BookDemoFormData = z.infer<typeof bookDemoSchema>

// Newsletter subscription validation
export const subscribeSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
})

export type SubscribeFormData = z.infer<typeof subscribeSchema>

// SMS form validation (E.164 format)
export const smsSchema = z.object({
  phone: z.string().regex(/^\+?[1-9]\d{1,14}$/, 'Invalid phone number (use E.164 format like +12125552368)'),
  message: z.string().min(1, 'Message cannot be empty').max(1600, 'Message is too long (max 1600 characters)'),
})

export type SMSFormData = z.infer<typeof smsSchema>
