import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

const FROM_EMAIL = process.env.FROM_EMAIL || 'Genesis AI Pro <noreply@genesisaipro.com>'
const BUSINESS_EMAIL = process.env.BUSINESS_EMAIL || 'team@genesisaipro.com'

export async function sendContactNotification(data: {
  firstName: string
  lastName: string
  email: string
  phone?: string
  message: string
}) {
  const { firstName, lastName, email, phone, message } = data

  // Send notification to business
  await resend.emails.send({
    from: FROM_EMAIL,
    to: BUSINESS_EMAIL,
    subject: `New Contact Form Submission from ${firstName} ${lastName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0B3C5D;">New Contact Form Submission</h2>
        <div style="background: #f5f5f5; padding: 20px; border-radius: 8px;">
          <p><strong>Name:</strong> ${firstName} ${lastName}</p>
          <p><strong>Email:</strong> ${email}</p>
          ${phone ? `<p><strong>Phone:</strong> ${phone}</p>` : ''}
          <p><strong>Message:</strong></p>
          <p style="background: white; padding: 15px; border-radius: 4px;">${message}</p>
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 20px;">
          Sent from Genesis AI Pro website
        </p>
      </div>
    `,
  })

  // Send confirmation to user
  await resend.emails.send({
    from: FROM_EMAIL,
    to: email,
    subject: 'Thank you for contacting Genesis AI Pro',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0B3C5D;">Thank You for Reaching Out!</h2>
        <p>Hi ${firstName},</p>
        <p>We've received your message and our team will get back to you within 24 hours.</p>
        <p>In the meantime, feel free to explore our features or book a demo to see Genesis AI Pro in action.</p>
        <div style="margin: 30px 0;">
          <a href="https://genesisaipro.com/#pricing" style="background: linear-gradient(135deg, #0B3C5D, #1C6EA4); color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">
            View Pricing
          </a>
        </div>
        <p>Best regards,<br>The Genesis AI Pro Team</p>
      </div>
    `,
  })
}

export async function sendDemoBookingNotification(data: {
  firstName: string
  lastName: string
  email: string
  phone?: string
  company?: string
  preferredDate: string
  preferredTime: string
  notes?: string
}) {
  const { firstName, lastName, email, phone, company, preferredDate, preferredTime, notes } = data

  // Send notification to business
  await resend.emails.send({
    from: FROM_EMAIL,
    to: BUSINESS_EMAIL,
    subject: `New Demo Request from ${firstName} ${lastName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0B3C5D;">New Demo Booking Request</h2>
        <div style="background: #f5f5f5; padding: 20px; border-radius: 8px;">
          <p><strong>Name:</strong> ${firstName} ${lastName}</p>
          <p><strong>Email:</strong> ${email}</p>
          ${phone ? `<p><strong>Phone:</strong> ${phone}</p>` : ''}
          ${company ? `<p><strong>Company:</strong> ${company}</p>` : ''}
          <p><strong>Preferred Date:</strong> ${preferredDate}</p>
          <p><strong>Preferred Time:</strong> ${preferredTime}</p>
          ${notes ? `<p><strong>Notes:</strong> ${notes}</p>` : ''}
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 20px;">
          Please follow up to confirm the demo time.
        </p>
      </div>
    `,
  })

  // Send confirmation to user
  await resend.emails.send({
    from: FROM_EMAIL,
    to: email,
    subject: 'Your Genesis AI Pro Demo Request',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0B3C5D;">Demo Request Received!</h2>
        <p>Hi ${firstName},</p>
        <p>Thank you for requesting a demo of Genesis AI Pro. We're excited to show you how our AI-powered platform can transform your business communications.</p>
        <div style="background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Requested Date:</strong> ${preferredDate}</p>
          <p><strong>Requested Time:</strong> ${preferredTime}</p>
        </div>
        <p>Our team will reach out within 24 hours to confirm your demo time.</p>
        <p>Best regards,<br>The Genesis AI Pro Team</p>
      </div>
    `,
  })
}

export async function sendSubscriptionConfirmation(email: string) {
  await resend.emails.send({
    from: FROM_EMAIL,
    to: email,
    subject: 'Welcome to Genesis AI Pro Updates',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0B3C5D;">You're In!</h2>
        <p>Thank you for subscribing to Genesis AI Pro updates.</p>
        <p>You'll be the first to know about:</p>
        <ul>
          <li>New features and product updates</li>
          <li>Industry insights and best practices</li>
          <li>Exclusive offers and early access</li>
        </ul>
        <div style="margin: 30px 0;">
          <a href="https://genesisaipro.com" style="background: linear-gradient(135deg, #0B3C5D, #1C6EA4); color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">
            Explore Genesis AI Pro
          </a>
        </div>
        <p>Best regards,<br>The Genesis AI Pro Team</p>
      </div>
    `,
  })

  // Notify business of new subscriber
  await resend.emails.send({
    from: FROM_EMAIL,
    to: BUSINESS_EMAIL,
    subject: 'New Newsletter Subscriber',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #0B3C5D;">New Subscriber</h2>
        <p><strong>Email:</strong> ${email}</p>
        <p style="color: #666; font-size: 12px; margin-top: 20px;">
          Subscribed via Genesis AI Pro website
        </p>
      </div>
    `,
  })
}
