# Genesis AI Pro - Quick Start Guide

## 🚀 Get Started in 3 Steps

### Step 1: Sign Up
1. Click "Sign Up" button on the home page
2. Fill in:
   - Full Name (e.g., "John Doe")
   - Email (e.g., "john@example.com")
   - Password (e.g., "SecurePassword123")
3. Click "Sign Up"
4. ✅ You're automatically logged in and sent to dashboard

### Step 2: Use Your Dashboard
1. See your personalized greeting
2. View quick stats
3. Browse all communication features
4. Click "Logout" when done

### Step 3: Sign Back In
1. Click "Sign In" on home page
2. Enter your email and password
3. Click "Sign In"
4. ✅ Back to your dashboard with all your data intact

---

## 💾 Your Data Persists

- Create account → Sign up stored your account in database
- Logout → Your session ends
- Come back tomorrow → Sign in with same credentials
- Everything is saved → Your data is always there

---

## 🔑 Test Credentials

After signing up, you can use the same credentials to sign in multiple times.

Example:
- Email: `test@example.com`
- Password: `MyPassword123`

---

## ✨ Key Features

### Authentication
✅ Email validation  
✅ Secure password hashing  
✅ Automatic login after signup  
✅ Session persistence  

### Dashboard
✅ User profile with name  
✅ Statistics dashboard  
✅ Communication feature grid  
✅ Quick action buttons  
✅ Logout button  

### Database
✅ PostgreSQL backend  
✅ Per-user data isolation  
✅ Automatic table creation  
✅ Secure connection  

---

## 🆘 Troubleshooting

### "Email already registered"
**Solution**: The email is already in use. Try signing in instead with `/login`.

### "Invalid email or password"
**Solution**: Double-check your credentials. Make sure caps lock is off and password is correct.

### "Page keeps redirecting"
**Solution**: Try clearing localStorage:
1. Open browser DevTools (F12)
2. Go to Application → Local Storage
3. Delete `user` key
4. Refresh page

### Can't see Sign Up/Sign In buttons
**Solution**: Click "Sign Up" or "Sign In" links at top-right of homepage or go directly to:
- `/signup` for sign up
- `/login` for sign in

---

## 📊 What Gets Stored

When you sign up, the system stores:
- ✅ Your name
- ✅ Your email (must be unique)
- ✅ Your hashed password (never stored in plain text)
- ✅ Account creation date

All future data (contacts, messages, calls) is also stored per user.

---

## 🎯 Next Steps After Sign Up

Once logged in to dashboard, you can:

1. **Add Contacts** - Click "Add Contact" button
2. **Send Messages** - Click "New Message" button  
3. **Schedule Calls** - Click "Schedule Call" button
4. **View Features** - Browse all communication modules

---

## ⚙️ Technical Details (For Developers)

**Flow Overview:**
```
Homepage → Sign Up/Sign In → API Verification → Dashboard → Session Maintained
```

**Behind the Scenes:**
1. Your password is hashed using bcryptjs
2. User data stored in PostgreSQL database
3. JWT token created for session
4. localStorage keeps you logged in
5. Each page checks for valid user

**No Extra Setup Needed:**
- Database auto-initializes on first signup
- Tables are created automatically
- SSL connection to PostgreSQL handled
- All environment variables already configured

---

## ✅ Status: Ready to Use

Your complete authentication system is working perfectly. Sign up now and start using your dashboard!
