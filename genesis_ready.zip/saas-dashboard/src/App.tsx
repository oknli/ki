import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useEffect } from "react";
import { setAuthTokenGetter } from "@workspace/api-client-react";

import { useGetMe } from "@workspace/api-client-react";

// Layout
import Layout from "./components/layout";

// Pages
import Login from "./pages/login";
import Signup from "./pages/signup";
import DashboardHome from "./pages/dashboard/home";
import SMS from "./pages/dashboard/sms";
import Email from "./pages/dashboard/email";
import Calls from "./pages/dashboard/calls";
import Chat from "./pages/dashboard/chat";
import Calendar from "./pages/dashboard/calendar";
import Inbox from "./pages/dashboard/inbox";
import NotFound from "./pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
      throwOnError: false,
    },
    mutations: {
      throwOnError: false,
    },
  },
});

setAuthTokenGetter(() => localStorage.getItem("authToken"));

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const [, setLocation] = useLocation();
  const { data: user, isLoading, isError } = useGetMe();

  useEffect(() => {
    if (!isLoading && isError) {
      setLocation("/login");
    }
  }, [isLoading, isError, setLocation]);

  if (isLoading) {
    return <div className="h-screen w-full flex items-center justify-center bg-background">
      <div className="animate-pulse flex flex-col items-center">
        <div className="h-12 w-12 rounded-full bg-primary/20 mb-4"></div>
        <div className="h-4 w-24 bg-muted rounded"></div>
      </div>
    </div>;
  }

  if (isError || !user) {
    return null;
  }

  return (
    <Layout user={user}>
      <Component />
    </Layout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => {
        const [, setLocation] = useLocation();
        useEffect(() => setLocation("/dashboard"), [setLocation]);
        return null;
      }} />
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/dashboard" component={() => <ProtectedRoute component={DashboardHome} />} />
      <Route path="/dashboard/sms" component={() => <ProtectedRoute component={SMS} />} />
      <Route path="/dashboard/email" component={() => <ProtectedRoute component={Email} />} />
      <Route path="/dashboard/calls" component={() => <ProtectedRoute component={Calls} />} />
      <Route path="/dashboard/chat" component={() => <ProtectedRoute component={Chat} />} />
      <Route path="/dashboard/calendar" component={() => <ProtectedRoute component={Calendar} />} />
      <Route path="/dashboard/inbox" component={() => <ProtectedRoute component={Inbox} />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
