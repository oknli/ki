import { useGetChatHistory, useSendChatMessage, getGetChatHistoryQueryKey } from "@workspace/api-client-react";
import { useState, useRef, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Bot, User } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export default function Chat() {
  const { data: history, isLoading } = useGetChatHistory();
  const [input, setInput] = useState("");
  const sendChat = useSendChatMessage();
  const queryClient = useQueryClient();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, sendChat.isPending]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const message = input;
    setInput("");

    sendChat.mutate(
      { data: { message } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetChatHistoryQueryKey() });
        }
      }
    );
  };

  return (
    <div className="h-full flex flex-col max-h-[100dvh] max-w-4xl mx-auto border-x bg-card shadow-sm">
      <div className="p-4 border-b bg-background flex items-center gap-3">
        <div className="bg-primary/10 p-2 rounded-full">
          <Bot className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h2 className="font-bold">Genesis AI Assistant</h2>
          <p className="text-xs text-muted-foreground">Always online</p>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 space-y-6" ref={scrollRef}>
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-16 w-[70%] rounded-2xl" />
            <Skeleton className="h-16 w-[70%] ml-auto rounded-2xl" />
          </div>
        ) : history?.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground opacity-50">
            <Bot className="h-16 w-16 mb-4" />
            <p>Send a message to start the conversation</p>
          </div>
        ) : (
          history?.map((msg) => (
            <div key={msg.id} className={cn("flex gap-3", msg.role === 'user' ? "flex-row-reverse" : "flex-row")}>
              <div className={cn(
                "h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1",
                msg.role === 'user' ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
              )}>
                {msg.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </div>
              <div className={cn(
                "max-w-[80%] rounded-2xl p-4 text-sm leading-relaxed",
                msg.role === 'user' 
                  ? "bg-primary text-primary-foreground rounded-tr-sm" 
                  : "bg-muted/50 border rounded-tl-sm text-foreground"
              )}>
                {msg.content}
              </div>
            </div>
          ))
        )}
        
        {sendChat.isPending && (
          <div className="flex gap-3">
            <div className="h-8 w-8 rounded-full bg-muted text-muted-foreground flex items-center justify-center flex-shrink-0 mt-1">
              <Bot className="h-4 w-4" />
            </div>
            <div className="bg-muted/50 border rounded-2xl rounded-tl-sm p-4 flex items-center gap-1">
              <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce"></span>
              <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: '0.2s' }}></span>
              <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: '0.4s' }}></span>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-background border-t">
        <form onSubmit={handleSend} className="relative flex items-center">
          <Input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask Genesis AI..." 
            className="pr-12 py-6 rounded-full bg-muted/30 border-muted focus-visible:ring-primary"
            disabled={sendChat.isPending}
          />
          <Button 
            type="submit" 
            size="icon" 
            className="absolute right-1.5 rounded-full h-9 w-9"
            disabled={sendChat.isPending || !input.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
        <div className="text-center mt-2">
          <span className="text-[10px] text-muted-foreground">AI may produce inaccurate information about people, places, or facts.</span>
        </div>
      </div>
    </div>
  );
}