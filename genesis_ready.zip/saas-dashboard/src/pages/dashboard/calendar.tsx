export default function Calendar() {
  return (
    <div className="h-full flex flex-col w-full bg-background">
      <div className="p-6 border-b bg-card">
        <h2 className="text-3xl font-bold tracking-tight">Calendar</h2>
        <p className="text-muted-foreground">Manage your bookings and availability.</p>
      </div>
      <div className="flex-1 w-full bg-background">
        <iframe 
          src="https://calendly.com/daryl-genesisaipro/30min?month=2026-04" 
          width="100%" 
          height="100%" 
          frameBorder="0"
          className="w-full h-full"
          title="Calendly Booking"
        ></iframe>
      </div>
    </div>
  );
}