import { useGetEmails, useCreateEmail, getGetEmailsQueryKey } from "@workspace/api-client-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { PenSquare, Send, User, Clock, Reply, Forward } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

export default function Email() {
  const { data: emails, isLoading } = useGetEmails();
  const [selectedEmail, setSelectedEmail] = useState<number | null>(null);
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [composeTo, setComposeTo] = useState("");
  const [composeSubject, setComposeSubject] = useState("");
  const [composeBody, setComposeBody] = useState("");

  const createEmail = useCreateEmail();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!composeTo || !composeSubject || !composeBody) return;

    createEmail.mutate(
      { data: { to: composeTo, subject: composeSubject, body: composeBody } },
      {
        onSuccess: () => {
          setIsComposeOpen(false);
          setComposeTo("");
          setComposeSubject("");
          setComposeBody("");
          toast({ title: "Email sent", description: "Your email has been sent successfully." });
          queryClient.invalidateQueries({ queryKey: getGetEmailsQueryKey() });
        },
        onError: () => {
          toast({ variant: "destructive", title: "Error", description: "Failed to send email." });
        }
      }
    );
  };

  const activeEmail = emails?.find(e => e.id === selectedEmail) || emails?.[0];

  return (
    <div className="h-full flex flex-col max-h-[100dvh]">
      <div className="p-6 border-b flex-shrink-0 flex justify-between items-center bg-card">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Email</h2>
          <p className="text-muted-foreground">Manage your email communications.</p>
        </div>
        <Dialog open={isComposeOpen} onOpenChange={setIsComposeOpen}>
          <DialogTrigger asChild>
            <Button><PenSquare className="mr-2 h-4 w-4" /> Compose</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>New Message</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSend} className="space-y-4 pt-4">
              <div className="grid grid-cols-[60px_1fr] items-center border-b pb-2">
                <span className="text-sm font-medium text-muted-foreground">To:</span>
                <Input value={composeTo} onChange={e => setComposeTo(e.target.value)} className="border-0 shadow-none focus-visible:ring-0 p-0" placeholder="recipient@example.com" />
              </div>
              <div className="grid grid-cols-[60px_1fr] items-center border-b pb-2">
                <span className="text-sm font-medium text-muted-foreground">Subject:</span>
                <Input value={composeSubject} onChange={e => setComposeSubject(e.target.value)} className="border-0 shadow-none focus-visible:ring-0 p-0" placeholder="Subject" />
              </div>
              <Textarea 
                value={composeBody} 
                onChange={e => setComposeBody(e.target.value)}
                className="min-h-[300px] border-0 shadow-none focus-visible:ring-0 p-0 resize-none" 
                placeholder="Write your message here..." 
              />
              <div className="flex justify-end pt-4 border-t">
                <Button type="submit" disabled={createEmail.isPending || !composeTo || !composeSubject || !composeBody}>
                  <Send className="mr-2 h-4 w-4" /> Send Message
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12 gap-0">
        <div className="border-r md:col-span-4 bg-muted/10 flex flex-col">
          <div className="p-4 border-b bg-card/50">
            <Input placeholder="Search emails..." className="bg-background" />
          </div>
          <ScrollArea className="flex-1">
            <div className="p-3 space-y-2">
              {isLoading ? (
                Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)
              ) : emails?.length === 0 ? (
                <div className="text-center p-8 text-muted-foreground">Inbox empty</div>
              ) : (
                emails?.map((email) => (
                  <button
                    key={email.id}
                    onClick={() => setSelectedEmail(email.id)}
                    className={`w-full text-left p-4 rounded-lg border transition-all ${activeEmail?.id === email.id ? 'bg-primary/5 border-primary/30 shadow-sm' : 'bg-card hover:bg-muted/50 border-transparent hover:border-border'}`}
                  >
                    <div className="flex justify-between items-baseline mb-1">
                      <span className="font-medium text-sm truncate pr-2">
                        {email.direction === 'inbound' ? email.from : `To: ${email.to}`}
                      </span>
                      <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                        {format(new Date(email.createdAt), "MMM d")}
                      </span>
                    </div>
                    <div className="font-medium text-xs mb-1 truncate text-foreground/90">{email.subject || '(No subject)'}</div>
                    <div className="text-xs text-muted-foreground line-clamp-2">{email.body}</div>
                  </button>
                ))
              )}
            </div>
          </ScrollArea>
        </div>

        <div className="md:col-span-8 flex flex-col bg-background">
          {activeEmail ? (
            <>
              <div className="p-6 border-b flex justify-between items-start bg-card">
                <div>
                  <h3 className="text-xl font-bold mb-4">{activeEmail.subject || '(No subject)'}</h3>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                      <User className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="font-medium text-sm">
                        {activeEmail.direction === 'inbound' ? activeEmail.from : `To: ${activeEmail.to}`}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {format(new Date(activeEmail.createdAt), "MMMM d, yyyy 'at' h:mm a")}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm"><Reply className="h-4 w-4 mr-2" /> Reply</Button>
                  <Button variant="outline" size="sm"><Forward className="h-4 w-4 mr-2" /> Forward</Button>
                </div>
              </div>
              <ScrollArea className="flex-1 p-8">
                <div className="prose dark:prose-invert max-w-none">
                  {activeEmail.body.split('\n').map((line, i) => (
                    <p key={i}>{line}</p>
                  ))}
                </div>
              </ScrollArea>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
              <Mail className="h-12 w-12 mb-4 opacity-20" />
              <p>Select an email to read</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}