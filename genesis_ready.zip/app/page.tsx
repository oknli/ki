'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Navbar } from "@/components/genesis/navbar"
import { Hero } from "@/components/genesis/hero"
import { Features } from "@/components/genesis/features"
import { Testimonials } from "@/components/genesis/testimonials"
import { Pricing } from "@/components/genesis/pricing"
import { FAQ } from "@/components/genesis/faq"
import { Contact } from "@/components/genesis/contact"
import { TextUsInstantly } from "@/components/genesis/text-us-instantly"
import { AgentChat } from "@/components/genesis/agent-chat"
import { CTA } from "@/components/genesis/cta"
import { Footer } from "@/components/genesis/footer"

export default function GenesisAIProPage() {
  const router = useRouter()

  useEffect(() => {
    // If already logged in, redirect to dashboard
    const user = localStorage.getItem('user')
    if (user) {
      router.push('/dashboard')
    }
  }, [router])

  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      <Features />
      <Testimonials />
      <Pricing />
      <FAQ />
      <Contact />
      <TextUsInstantly />
      <AgentChat />
      <CTA />
      <Footer />
    </main>
  )
}
