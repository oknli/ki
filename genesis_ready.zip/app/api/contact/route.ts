import { NextResponse } from 'next/server'
import { contactSchema } from '@/lib/validation'
import { sendContactNotification } from '@/lib/email'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    
    // Validate input
    const result = contactSchema.safeParse(body)
    if (!result.success) {
      return NextResponse.json(
        { error: result.error.errors[0].message },
        { status: 400 }
      )
    }

    // Send emails
    await sendContactNotification(result.data)

    return NextResponse.json({ 
      success: true,
      message: 'Your message has been sent successfully!' 
    })
  } catch (error) {
    console.error('Contact form error:', error)
    return NextResponse.json(
      { error: 'Failed to send message. Please try again.' },
      { status: 500 }
    )
  }
}
