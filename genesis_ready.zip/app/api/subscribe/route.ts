import { NextResponse } from 'next/server'
import { subscribeSchema } from '@/lib/validation'
import { sendSubscriptionConfirmation } from '@/lib/email'

export async function POST(req: Request) {
  try {
    const body = await req.json()
    
    // Validate input
    const result = subscribeSchema.safeParse(body)
    if (!result.success) {
      return NextResponse.json(
        { error: result.error.errors[0].message },
        { status: 400 }
      )
    }

    // Send confirmation email
    await sendSubscriptionConfirmation(result.data.email)

    return NextResponse.json({ 
      success: true,
      message: 'You\'re subscribed! Check your email for confirmation.' 
    })
  } catch (error) {
    console.error('Subscribe error:', error)
    return NextResponse.json(
      { error: 'Failed to subscribe. Please try again.' },
      { status: 500 }
    )
  }
}
